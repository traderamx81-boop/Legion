const mongoose = require('mongoose');

const authMiddlewareSchema = new mongoose.Schema({});

// Auth middleware function
const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  try {
    const jwt = require('jsonwebtoken');
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
    req.userId = decoded.userId || decoded.id;
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
};

// Admin middleware
const adminMiddleware = (req, res, next) => {
  if (!req.user || !['admin', 'mod', 'developer'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
};

// Optional auth middleware (doesn't fail if no token)
const optionalAuth = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (token) {
    try {
      const jwt = require('jsonwebtoken');
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
      req.userId = decoded.userId || decoded.id;
      req.user = decoded;
    } catch (err) {
      // Token invalid but that's okay for optional auth
    }
  }
  next();
};

module.exports = {
  authMiddleware,
  adminMiddleware,
  optionalAuth
};

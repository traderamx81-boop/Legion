const yomu = require('yomu-api');
const FuzzyMatcher = require('../../utils/fuzzyMatcher');

// Fire-style: getChapterImages(chapterId) + getChapters(mangaId) directly
const FIRE_STYLE_PROVIDERS = new Set(['mangafire', 'weebcentral', 'mangadot']);
// These use provider.search() instead of provider.searchManga()
const SEARCH_PROVIDERS = new Set(['mangafire', 'weebcentral', 'mangadot', 'mangapill']);

class Yomu {
    constructor() {
        this.providers = {
            'mangafire':   yomu.models.mangafire,
            'mangapill':   yomu.models.mangaPill,   // used for search only
            'flamecomics': yomu.models.flamecomics,
            'mangapark':   yomu.models.mangapark,
            'weebcentral': yomu.models.weebcentral,
            'mangadot':    yomu.models.mangadot,
        };
        // MangaPillModel internals are broken (wrong scraper method names),
        // so we keep a direct scraper instance for chapters/pages.
        this.mangapillScraper = new yomu.scrapers.mangapill();
        this.name = 'yomu';
    }

    getProvider(name) {
        const p = this.providers[name.toLowerCase()];
        if (!p) throw new Error(`Yomu manga provider ${name} not found`);
        return p;
    }

    async executeProviderRequestWithRetry(requestFn, providerName, retries = 3) {
        for (let attempt = 0; attempt <= retries; attempt++) {
            try {
                return await requestFn();
            } catch (error) {
                if (this.isLogicalFailure(error)) throw error;
                if (attempt === retries) throw error;
                const totalDelay = (2500 * Math.pow(1.5, attempt)) + (Math.random() * 1000);
                await this.delay(totalDelay);
            }
        }
    }

    isLogicalFailure(error) {
        if (!error || !error.message) return false;
        const msg = error.message.toLowerCase();
        const status = error.response?.status;
        return status === 404 || msg.includes('not found') || msg.includes('no results') || msg.includes('invalid id');
    }

    delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

    async search(providerName, query, page = 1) {
        const provider = this.getProvider(providerName);
        const results = await this.executeProviderRequestWithRetry(
            () => {
                if (typeof provider.search === 'function') {
                    return provider.search(query, page);
                }
                if (typeof provider.searchManga === 'function') {
                    return provider.searchManga(query);
                }
                throw new Error(`Provider ${providerName} does not support search`);
            },
            providerName
        );
        return results;
    }

    async resolveMangaId(providerName, title, altTitles = []) {
        try {
            const results = await this.search(providerName, title);
            const items = results.results || results;
            if (!items || items.length === 0) return null;

            const { match } = FuzzyMatcher.findBestMatch(title, items, ['title', 'name']);
            if (match) return match.id || match.session;

            return items[0].id || items[0].session;
        } catch (error) {
            console.warn(`Yomu (${providerName}) resolveMangaId error:`, error.message);
            return null;
        }
    }

    async getChapters(providerName, mangaId, language = 'en') {
        const provider = this.getProvider(providerName);

        // MangaFire: language-aware chapter fetching — use page='all' to get the complete list
        if (providerName === 'mangafire') {
            let chaptersData = await this.executeProviderRequestWithRetry(
                () => provider.getChapters(mangaId, language, 'all'),
                providerName
            );
            // If we got a language list instead of chapters, retry with the first lang
            if (Array.isArray(chaptersData) && chaptersData.length > 0 && chaptersData[0].chapters) {
                const firstLang = chaptersData[0].id;
                chaptersData = await this.executeProviderRequestWithRetry(
                    () => provider.getChapters(mangaId, firstLang, 'all'),
                    providerName
                );
            }
            if (!chaptersData || !chaptersData.length) return [];
            return chaptersData.map(ch => ({
                id: ch.chapterId || ch.id || ch.session,
                number: ch.number || ch.episode || ch.chapter,
                title: ch.title || `Chapter ${ch.number || ch.episode || ch.chapter || 'N/A'}`,
                date: ch.date || ch.created_at || ch.release_date
            }));
        }

        // MangaPill: use raw scraper (model internals are broken)
        if (providerName === 'mangapill') {
            const info = await this.executeProviderRequestWithRetry(
                () => this.mangapillScraper.getMangaById(mangaId),
                providerName
            );
            if (!info || !info.chapters) return [];
            return info.chapters.map(ch => {
                const titleStr = ch.title || '';
                const m = titleStr.match(/(?:chapter|ch\.?)\s*(\d+(?:\.\d+)?)/i);
                const num = m ? m[1] : null;
                return {
                    id: ch.id,
                    number: num,
                    title: ch.title || `Chapter ${num || 'N/A'}`,
                    date: ch.date
                };
            });
        }

        // WeebCentral / MangaDot: getChapters(mangaId) — weebcentral returns { mangaId, chapters }
        if (FIRE_STYLE_PROVIDERS.has(providerName)) {
            const chaptersData = await this.executeProviderRequestWithRetry(
                () => provider.getChapters(mangaId),
                providerName
            );
            // weebcentral returns { mangaId, totalChapters, chapters: [...] }
            // mangadot returns an array directly
            const list = Array.isArray(chaptersData) ? chaptersData : (chaptersData?.chapters || []);
            const mapped = list.map(ch => {
                // Prefer explicit number fields, otherwise parse from title/name
                let num = ch.number ?? ch.chapter ?? ch.chapterNumber ?? null;
                if (num == null) {
                    const nameStr = ch.title || ch.name || '';
                    const m = nameStr.match(/(?:chapter|ch\.?)\s*(\d+(?:\.\d+)?)/i)
                        || nameStr.match(/(\d+(?:\.\d+)?)\s*$/);
                    if (m) num = m[1];
                }
                return {
                    id: ch.id || ch.chapterId || ch.session,
                    number: num,
                    title: ch.title || ch.name || `Chapter ${num || 'N/A'}`,
                    date: ch.date || ch.updatedAt || ch.release_date,
                    _source: ch.source || null,
                };
            });

            // Deduplicate by chapter number — mangadot can have multiple scanlations
            // per chapter. Keep 'scraper' source first, otherwise the entry with the smallest ID.
            if (providerName === 'mangadot') {
                const seen = new Map();
                // Sort: scraper before user, then by ascending numeric chapterId
                const sorted = [...mapped].sort((a, b) => {
                    if (a._source === 'scraper' && b._source !== 'scraper') return -1;
                    if (b._source === 'scraper' && a._source !== 'scraper') return 1;
                    return (Number(a.id) || 0) - (Number(b.id) || 0);
                });
                for (const ch of sorted) {
                    const key = ch.number != null ? String(ch.number) : String(ch.id);
                    if (!seen.has(key)) seen.set(key, ch);
                }
                return [...seen.values()];
            }

            return mapped;
        }

        // Pill-style: getMangaById returns { chapters: [...] }
        const info = await this.executeProviderRequestWithRetry(
            () => provider.getMangaById(mangaId),
            providerName
        );
        if (!info || !info.chapters) return [];
        return info.chapters.map(ch => {
            let num = ch.number || ch.chapter;
            if (num === undefined || num === null) {
                const titleStr = ch.title || '';
                const m = titleStr.match(/(?:chapter|ch\.?)\s*(\d+(?:\.\d+)?)/i);
                if (m && m[1]) {
                    num = m[1];
                } else {
                    const idStr = ch.id || '';
                    const im = idStr.match(/(?:chapter|ch[-/])(\d+(?:\.\d+)?)/i);
                    if (im && im[1]) num = im[1];
                }
            }
            return {
                id: ch.id,
                number: num,
                title: ch.title || `Chapter ${num || 'N/A'}`,
                date: ch.date
            };
        });
    }

    async getPages(providerName, chapterId, mangaId) {
        const provider = this.getProvider(providerName);

        // MangaPill: use raw scraper — getMangaChapter(chapterId) only, no mangaId
        if (providerName === 'mangapill') {
            const pageData = await this.executeProviderRequestWithRetry(
                () => this.mangapillScraper.getMangaChapter(chapterId),
                providerName
            );
            return { pages: pageData.pages || pageData.images || pageData };
        }

        // Fire-style: getChapterImages(chapterId) → { images: [{page, image}] } or plain array
        if (FIRE_STYLE_PROVIDERS.has(providerName)) {
            const pageData = await this.executeProviderRequestWithRetry(
                () => provider.getChapterImages(chapterId),
                providerName
            );
            const rawPages = pageData.images || pageData.pages || pageData;
            // Normalize: scrapers may return objects {page, image} or plain URL strings
            const pages = Array.isArray(rawPages)
                ? rawPages.map(p => (typeof p === 'string' ? p : (p.image || p.url || p.src || '')))
                : [];
            return { pages };
        }
        // Flame-style: getMangaChapter(mangaId, chapterId)
        const pageData = await this.executeProviderRequestWithRetry(
            () => provider.getMangaChapter(mangaId, chapterId),
            providerName
        );
        return { pages: pageData.images || pageData.pages || pageData };
    }
}

module.exports = new Yomu();

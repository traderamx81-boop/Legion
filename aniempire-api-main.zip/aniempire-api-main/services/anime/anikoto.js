const { scrapeSearch, scrapeAnimeEpisodes, scrapeWatch, scrapeWatchStream, fetchJson } = require('anikoto-api');
const FuzzyMatcher = require('../../utils/fuzzyMatcher');

// The referer domain that Anikoto streams require — set as the `embed` field
// so that the Katalyst proxy can inject it when fetching .m3u8 / .ts segments
const STREAM_REFERER = 'https://megaplay.buzz/';

// Nekostream mapper API — provides Kiwi-Stream link IDs per MAL episode
const MAPPER_URL = 'https://mapper.nekostream.site/api/mal';

/**
 * Fetch Kiwi-Stream server entries from the nekostream mapper API.
 * Returns an array of { name, cat, linkId } ready to be resolved via /ajax/server?get=.
 *
 * @param {string} dataMal   - MAL ID (from episode data-mal attribute)
 * @param {string} epNumber  - Episode number
 * @param {string} dataTimestamp - Timestamp (from episode data-timestamp attribute)
 */
async function fetchKiwiSources(dataMal, epNumber, dataTimestamp) {
    if (!dataMal || !dataTimestamp) {
        console.warn(`[Anikoto Local] fetchKiwiSources: missing dataMal=${dataMal} or dataTimestamp=${dataTimestamp} — skipping Kiwi mapper`);
        return { sources: [], downloads: [] };
    }
    const maxRetries = 2;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
            const mapperData = await fetchJson(
                `${MAPPER_URL}/${dataMal}/${epNumber}/${dataTimestamp}`,
                { 'X-Requested-With': '' } // override to avoid AJAX-only header
            );
            if (!mapperData || typeof mapperData !== 'object') return { sources: [], downloads: [] };

            const sources = [];
            const downloads = [];
            
            for (const [serverKey, serverVal] of Object.entries(mapperData)) {
                if (serverKey === 'status' || typeof serverVal !== 'object') continue;

                for (const [catKey, catData] of Object.entries(serverVal)) {
                    if (catKey !== 'sub' && catKey !== 'dub') continue;
                    if (!catData || typeof catData !== 'object') continue;

                    // Extract download portals (like Kiwi-Stream, StreamWish, etc.)
                    if (catData.download && typeof catData.download === 'object') {
                        for (const [dlServerName, dlUrl] of Object.entries(catData.download)) {
                            downloads.push({
                                downloadPage: dlUrl,
                                server: dlServerName,
                                isDub: catKey === 'dub'
                            });
                        }
                    }

                    // Skip entries that don't have a streaming URL
                    if (!catData.url) continue;

                    const name = serverKey.replace(/-+$/, '');
                    sources.push({ name, cat: catKey, linkId: catData.url });
                }
            }
            return { sources, downloads };
        } catch (e) {
            if (attempt < maxRetries) {
                console.warn(`[Anikoto Local] Kiwi mapper attempt ${attempt + 1} failed: ${e.message}, retrying in 400ms...`);
                await new Promise(r => setTimeout(r, 400));
            } else {
                console.warn(`[Anikoto Local] Kiwi mapper failed after ${maxRetries + 1} attempts: ${e.message}`);
                return { sources: [], downloads: [] };
            }
        }
    }
    return { sources: [], downloads: [] };
};

/**
 * Host substitution map extracted from mewcdn.online/player/plyr.php.
 * The frontend player intercepts XHR/fetch and rewrites these domains so that
 * vibeplayer.site (Cloudflare-protected) is never actually hit — instead all
 * real CDN traffic goes to the mapped hostname.
 */
const KIWI_HOST_MAP = {
    'vibeplayer.site':    'nanobyte.bigdreamsmalldih.site',
    'vault-10.owocdn.top': '10.bigdreamsmalldih.site',
    'vault-11.owocdn.top': '11.bigdreamsmalldih.site',
    'vault-12.owocdn.top': '12.bigdreamsmalldih.site',
    'vault-13.owocdn.top': '13.bigdreamsmalldih.site',
    'vault-14.owocdn.top': '14.bigdreamsmalldih.site',
    'vault-15.owocdn.top': '15.bigdreamsmalldih.site',
    'vault-16.owocdn.top': '16.bigdreamsmalldih.site',
    'vault-99.owocdn.top': '99.bigdreamsmalldih.site',
    'vault-01.uwucdn.top': 'uwu1.bigdreamsmalldih.site',
    'vault-02.uwucdn.top': 'uwu2.bigdreamsmalldih.site',
    'vault-03.uwucdn.top': 'uwu3.bigdreamsmalldih.site',
    'vault-04.uwucdn.top': 'uwu4.bigdreamsmalldih.site',
    'vault-05.uwucdn.top': 'uwu5.bigdreamsmalldih.site',
    'vault-06.uwucdn.top': 'uwu6.bigdreamsmalldih.site',
    'vault-07.uwucdn.top': 'uwu7.bigdreamsmalldih.site',
    'vault-08.uwucdn.top': 'uwu8.bigdreamsmalldih.site',
    'vault-09.uwucdn.top': 'uwu9.bigdreamsmalldih.site',
    'vault-10.uwucdn.top': 'uwu10.bigdreamsmalldih.site',
    'vault-11.uwucdn.top': 'uwu11.bigdreamsmalldih.site',
    'vault-12.uwucdn.top': 'uwu12.bigdreamsmalldih.site',
    'vault-13.uwucdn.top': 'uwu13.bigdreamsmalldih.site',
    'vault-14.uwucdn.top': 'uwu14.bigdreamsmalldih.site',
    'vault-15.uwucdn.top': 'uwu15.bigdreamsmalldih.site',
    'vault-16.uwucdn.top': 'uwu16.bigdreamsmalldih.site',
    'vault-99.uwucdn.top': 'uwu17.bigdreamsmalldih.site',
};

/**
 * Apply the mewcdn HOST_MAP substitution to a URL.
 * e.g. https://vibeplayer.site/... → https://nanobyte.bigdreamsmalldih.site/...
 */
function applyKiwiHostMap(url) {
    if (!url) return url;
    let out = url;
    for (const [origin, mapped] of Object.entries(KIWI_HOST_MAP)) {
        if (out.includes(origin)) {
            out = out.split(origin).join(mapped);
        }
    }
    return out;
}

/**
 * Parse an HLS master playlist text and return variant stream URLs.
 * Returns an array of { url, resolution, bandwidth } sorted best-first.
 */
function parseHLSMasterVariants(masterText, baseUrl) {
    const variants = [];
    const lines = masterText.split('\n');
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line.startsWith('#EXT-X-STREAM-INF')) continue;
        const nextLine = (lines[i + 1] || '').trim();
        if (!nextLine || nextLine.startsWith('#')) continue;

        const bwMatch = line.match(/BANDWIDTH=(\d+)/i);
        const resMatch = line.match(/RESOLUTION=(\d+x\d+)/i);
        const bandwidth = bwMatch ? parseInt(bwMatch[1]) : 0;
        const resolution = resMatch ? resMatch[1] : 'auto';

        // Resolve relative URLs against the master URL base
        let variantUrl = nextLine;
        if (!variantUrl.startsWith('http')) {
            try {
                const base = new URL(baseUrl);
                variantUrl = new URL(nextLine, base).href;
            } catch (_) {}
        }
        // Apply host substitution to variant URL too
        variantUrl = applyKiwiHostMap(variantUrl);
        variants.push({ url: variantUrl, resolution, bandwidth });
    }
    // Sort highest-bandwidth first
    variants.sort((a, b) => b.bandwidth - a.bandwidth);
    return variants;
}

/**
 * Normalize an HLS RESOLUTION= string (e.g. "1920x1080") to a user-friendly
 * quality label (e.g. "1080p"). Falls back to the input if it can't be parsed.
 */
function normalizeResolution(resolution) {
    if (!resolution) return 'auto';
    // "WxH" → "Hp"
    const match = resolution.match(/^\d+[xX](\d+)$/);
    if (match) return `${match[1]}p`;
    // Already in "1080p" format or "auto"
    return resolution;
}

// ── KATALYST PROXY BASE ──────────────────────────────────────────────────────
// Use the remote Katalyst deployment to fetch embed pages.
// Katalyst has fast internet while the local server may be slow/throttled.
// Uses STREAM_PROXY_URL (same env var as the rest of aniempire-api uses for Katalyst).
const KATALYST_BASE = (() => {
    try {
        const proxyUrl = process.env.STREAM_PROXY_URL;
        return proxyUrl ? new URL(proxyUrl).origin : 'http://localhost:3001';
    } catch (_) { return 'http://localhost:3001'; }
})();


/**
 * Fetch HTML content of a URL via the Katalyst /fetch proxy endpoint.
 * This routes through the remote Katalyst server which has reliable CDN access,
 * bypassing the user's local slow-internet connection.
 * Falls back to a direct fetch if Katalyst is unavailable or returns an error.
 */
async function fetchViaProxy(url, referer, timeoutMs = 10000) {
    const encodedUrl = encodeURIComponent(url);
    const encodedRef = referer ? `&referrer=${encodeURIComponent(referer)}` : '';
    const proxyUrl = `${KATALYST_BASE}/api/stream/fetch?url=${encodedUrl}${encodedRef}`;

    try {
        const res = await fetch(proxyUrl, {
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36' },
            signal: AbortSignal.timeout(timeoutMs),
        });
        if (res.ok) {
            const text = await res.text();
            if (text && text.length > 100) return text; // Valid HTML response
        }
        console.warn(`[Anikoto Local] Katalyst /fetch returned ${res.status}, falling back to direct fetch...`);
    } catch (proxyErr) {
        console.warn(`[Anikoto Local] Katalyst proxy fetch failed (${proxyErr.message}), falling back to direct fetch...`);
    }

    // Direct fallback — used if Katalyst is down or misconfigured
    const directRes = await fetch(url, {
        headers: {
            'Referer': referer || url,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
        signal: AbortSignal.timeout(timeoutMs),
    });
    if (!directRes.ok) throw new Error(`HTTP ${directRes.status}`);
    return directRes.text();
}


/**
 * Direct MegaPlay HLS extractor — bypasses scrapeWatch entirely.
 *
 * Replicates extractMegaplay from the npm package but:
 *  1. Fetches the embed HTML via Katalyst proxy (fast remote server)
 *  2. Calls the getSources API directly with a short timeout
 *
 * Works for: megaplay.buzz, vidwish.live, vidtube.site, megacloud.bloggy.click
 * (HD-1, VidPlay-1 on vidtube.site)
 *
 * @returns {{ m3u8, referer, tracks, intro, outro, allSources } | null}
 */
async function extractMegaplayDirect(embedUrl, referer) {
    try {
        // Some hostnames use alternate domains — normalize to megaplay.buzz
        const hostname = new URL(embedUrl).hostname;
        let resolvedUrl = embedUrl;
        if (hostname.includes('vidwish.live') || hostname.includes('megacloud.bloggy.click')) {
            resolvedUrl = embedUrl.replace('vidwish.live', 'megaplay.buzz').replace('megacloud.bloggy.click', 'megaplay.buzz');
        }

        const host = new URL(resolvedUrl).host;
        const embedReferer = `https://${host}/`;

        // Step 1: Fetch embed HTML via Katalyst proxy (avoids local slow-internet timeouts)
        console.log(`[Anikoto Local] extractMegaplayDirect: fetching ${resolvedUrl} via Katalyst...`);
        const html = await fetchViaProxy(resolvedUrl, embedReferer, 8000);

        // Step 2: Extract file ID from <title>File {id}
        const match = html.match(/<title>File ([0-9]+)/);
        if (!match) {
            console.warn(`[Anikoto Local] extractMegaplayDirect: no file ID in HTML for ${resolvedUrl}`);
            return null;
        }
        const fileId = match[1];

        // Determine dub/sub type param
        let typeParam = '';
        if (resolvedUrl.includes('/dub')) {
            typeParam = '&type=dub';
        } else {
            const typeMatch = html.match(/type:\s*'([^']+)'/);
            if (typeMatch && typeMatch[1] === 'dub') typeParam = '&type=dub';
        }

        // Step 3: Call the getSources API directly (this is a lightweight JSON endpoint)
        const sourcesUrl = `https://${host}/stream/getSources?id=${fileId}${typeParam}`;
        console.log(`[Anikoto Local] extractMegaplayDirect: calling ${sourcesUrl}`);
        const apiRes = await fetch(sourcesUrl, {
            headers: {
                'Referer': embedReferer,
                'X-Requested-With': 'XMLHttpRequest',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            },
            signal: AbortSignal.timeout(8000),
        });
        if (!apiRes.ok) throw new Error(`getSources HTTP ${apiRes.status}`);
        const data = await apiRes.json();

        let m3u8 = data?.sources?.file;
        if (!m3u8) {
            console.warn(`[Anikoto Local] extractMegaplayDirect: no m3u8 in getSources response`);
            return null;
        }

        // Fix mewstream.buzz CDN host (unreliable) by using the subtitle track's CDN domain
        if (m3u8.includes('mewstream.buzz')) {
            const tracks = data?.tracks || [];
            const firstTrack = tracks.find(t => t.file && !t.file.includes('mewstream.buzz'));
            if (firstTrack) {
                try {
                    const replacementHost = new URL(firstTrack.file).host;
                    m3u8 = m3u8.replace(new URL(m3u8).host, replacementHost);
                } catch (_) {}
            }
        }

        console.log(`[Anikoto Local] extractMegaplayDirect: got m3u8 ${m3u8.substring(0, 80)}...`);
        return {
            m3u8,
            referer: embedReferer,
            tracks: data?.tracks || [],
            intro: (typeof data?.intro?.start === 'number') ? data.intro : null,
            outro: (typeof data?.outro?.start === 'number') ? data.outro : null,
        };
    } catch (err) {
        console.warn(`[Anikoto Local] extractMegaplayDirect failed: ${err.message}`);
        return null;
    }
}

/**
 * Direct Vidstream HLS extractor — bypasses scrapeWatch entirely.
 *
 * Replicates extractVidstream from the npm package but routes through Katalyst.
 * Works for: vidtub.norami.top (VidPlay-1), Vidstream-2
 *
 * @returns {{ m3u8, referer, tracks, allSources } | null}
 */
async function extractVidstreamDirect(embedUrl, referer) {
    try {
        const host = new URL(embedUrl).host;
        const embedReferer = `https://${host}/`;

        // Step 1: Fetch embed HTML via Katalyst proxy
        console.log(`[Anikoto Local] extractVidstreamDirect: fetching ${embedUrl} via Katalyst...`);
        const html = await fetchViaProxy(embedUrl, embedReferer, 8000);

        // Step 2: Parse critical fields from the HTML
        const epIdMatch = html.match(/data-ep-id=["'](\d+)["']/);
        const typeMatch = html.match(/type:\s*'(\w+)'/);
        const domain2Match = html.match(/domain2_url:\s*'([^']+)'/);

        if (!epIdMatch || !typeMatch || !domain2Match) {
            console.warn(`[Anikoto Local] extractVidstreamDirect: missing ep-id/type/domain2 in HTML`);
            return null;
        }

        const epId = epIdMatch[1];
        const epType = typeMatch[1];
        const domain2 = domain2Match[1].trim();

        // Step 3: Call the data API
        const saveDataUrl = `${domain2}/save_data.php?id=${epId}-${epType}`;
        console.log(`[Anikoto Local] extractVidstreamDirect: calling ${saveDataUrl}`);
        const apiRes = await fetch(saveDataUrl, {
            headers: {
                'Referer': embedReferer,
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            },
            signal: AbortSignal.timeout(8000),
        });
        if (!apiRes.ok) throw new Error(`save_data HTTP ${apiRes.status}`);
        const data = await apiRes.json();

        const sources = data?.data?.sources ?? [];
        const tracks = data?.data?.tracks ?? [];
        const m3u8 = sources[0]?.url ?? null;

        if (!m3u8) {
            console.warn(`[Anikoto Local] extractVidstreamDirect: no m3u8 in save_data response`);
            return null;
        }

        const allSources = sources
            .filter(s => s.url)
            .map(s => ({ url: s.url, quality: s.label || s.type || s.quality || 'auto' }));

        console.log(`[Anikoto Local] extractVidstreamDirect: got m3u8 ${m3u8.substring(0, 80)}...`);
        return {
            m3u8,
            referer: `${domain2}/`,
            tracks,
            allSources: allSources.length > 1 ? allSources : undefined,
        };
    } catch (err) {
        console.warn(`[Anikoto Local] extractVidstreamDirect failed: ${err.message}`);
        return null;
    }
}

/**
 * Route an embed URL to the appropriate direct extractor.
 * Returns extracted HLS stream data or null if extraction failed.
 */
async function extractStreamDirect(embedUrl, referer) {
    if (!embedUrl) return null;
    try {
        const hostname = new URL(embedUrl).hostname;
        if (
            hostname.includes('megaplay.buzz') ||
            hostname.includes('vidwish.live') ||
            hostname.includes('megacloud.bloggy.click') ||
            hostname.includes('vidtube.site')
        ) {
            return extractMegaplayDirect(embedUrl, referer);
        }
        if (
            hostname.includes('vidtub.') ||
            hostname.includes('vidstream') ||
            hostname.includes('norami') ||
            hostname.includes('shiora')
        ) {
            // vidtub.norami.top = VidPlay CDN, megap.shiora.top = HD-1 CDN
            // but the embed URL for these might be megaplay.buzz — check the HTML approach
            return extractMegaplayDirect(embedUrl, referer);
        }
        // Unknown host — try Megaplay first, Vidstream as fallback
        const megaResult = await extractMegaplayDirect(embedUrl, referer);
        if (megaResult) return megaResult;
        return extractVidstreamDirect(embedUrl, referer);
    } catch (_) {
        return null;
    }
}



/**
 * Given a Kiwi-Stream resolved embed URL (e.g. mewcdn.online/player/plyr.php#<b64>),
 * decode the base64 fragment as a direct HLS URL, apply the HOST_MAP substitution
 * so the real CDN host is used, then fetch the master.m3u8 to resolve quality variants.
 *
 * Returns { m3u8, referer, allSources } if successful, or null otherwise.
 */
async function resolveKiwiHLS(embedUrl, kiwiReferer) {
    try {
        const hashIdx = embedUrl.indexOf('#');
        if (hashIdx === -1) return null;
        const fragment = embedUrl.slice(hashIdx + 1);
        if (!fragment) return null;

        // Strip any trailing # segments (some URLs have double ##)
        const b64 = fragment.split('#')[0];
        const decoded = Buffer.from(b64, 'base64').toString('utf-8');
        if (!decoded.startsWith('http') || !decoded.includes('.m3u8')) return null;

        // Apply the HOST_MAP: vibeplayer.site → nanobyte.bigdreamsmalldih.site
        // Without this, the URL times out due to Cloudflare protection on vibeplayer.site
        const proxiedMasterUrl = applyKiwiHostMap(decoded);
        console.log(`[Anikoto Local] Kiwi HLS: decoded ${decoded} → proxied ${proxiedMasterUrl}`);

        // Fetch the master.m3u8 from the real CDN host (with 1 quick retry)
        let masterText = null;
        for (let attempt = 0; attempt <= 1; attempt++) {
            try {
                const masterRes = await fetch(proxiedMasterUrl, {
                    headers: {
                        'Referer': kiwiReferer || 'https://mewcdn.online/',
                        'Origin': 'https://mewcdn.online',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                    },
                    signal: AbortSignal.timeout(6000),
                });
                if (masterRes.ok) {
                    masterText = await masterRes.text();
                    break;
                }
            } catch (fetchErr) {
                if (attempt === 0) {
                    console.warn(`[Anikoto Local] Kiwi master.m3u8 fetch attempt 1 failed (${fetchErr.message}), retrying in 500ms...`);
                    await new Promise(r => setTimeout(r, 500));
                } else {
                    console.warn(`[Anikoto Local] Kiwi master.m3u8 fetch failed: ${fetchErr.message}`);
                }
            }
        }

        if (masterText && masterText.includes('#EXTM3U')) {
            const variants = parseHLSMasterVariants(masterText, proxiedMasterUrl);
            if (variants.length > 0) {
                console.log(`[Anikoto Local] Kiwi HLS resolved ${variants.length} quality levels: ${variants.map(v => normalizeResolution(v.resolution)).join(', ')}`);
                // Best quality URL as the primary m3u8
                const best = variants[0];
                return {
                    m3u8: best.url,
                    referer: 'https://mewcdn.online/',
                    allSources: [
                        { url: proxiedMasterUrl, quality: 'auto' },
                        ...variants.map(v => ({ url: v.url, quality: normalizeResolution(v.resolution) }))
                    ],
                };
            }
            // Master has no variants — might itself be a media playlist; use it directly
            console.log(`[Anikoto Local] Kiwi HLS: master has no variants, using directly`);
            return { m3u8: proxiedMasterUrl, referer: 'https://mewcdn.online/' };
        }

        // Fetch failed or not valid HLS — return the proxied URL as-is and hope for the best
        console.warn(`[Anikoto Local] Kiwi master.m3u8 not fetchable, returning proxied URL`);
        return { m3u8: proxiedMasterUrl, referer: 'https://mewcdn.online/' };
    } catch (_) {}
    return null;
}

class AnikotoProvider {
    constructor() {
        this.name = 'anikoto';
        // In-memory cache for server lists — keyed by episodeId, TTL 5 minutes
        // Prevents re-running the 15s AJAX fetchJson call on every page navigation
        this._serverListCache = new Map();
        this._serverListCacheTTL = 5 * 60 * 1000; // 5 minutes
        // Downloads cache — keyed by episodeId, populated alongside server list
        this._downloadCache = new Map();
    }

    delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

    async executeWithRetry(requestFn, retries = 2) {
        for (let attempt = 0; attempt <= retries; attempt++) {
            try {
                return await requestFn();
            } catch (error) {
                if (attempt === retries) throw error;
                await this.delay((1500 * Math.pow(1.5, attempt)) + Math.random() * 500);
            }
        }
    }

    /**
     * Search for an anime by title.
     * Returns an array of { slug, title } candidates.
     */
    async search(title) {
        try {
            const data = await this.executeWithRetry(() => scrapeSearch(title));
            if (!data || !data.results) return [];
            return data.results; // [ { slug, title, image, ... } ]
        } catch (e) {
            console.error(`[Anikoto Local] Search failed for ${title}: ${e.message}`);
            return [];
        }
    }

    /**
     * Resolve a title (+ alt titles) to an Anikoto slug.
     * @returns {string|null} slug
     */
    async resolveAnimeId(title, altTitles = [], malId, anilistId) {
        const seen = new Set();
        const titlesToTry = [title, ...altTitles].filter(t => {
            if (!t) return false;
            const norm = t.toLowerCase().trim();
            if (seen.has(norm)) return false;
            seen.add(norm);
            return true;
        }).slice(0, 5);

        for (const searchTitle of titlesToTry) {
            try {
                const results = await Promise.race([
                    this.search(searchTitle),
                    new Promise((_, reject) => setTimeout(() => reject(new Error('search timeout')), 8000))
                ]);

                if (!results || results.length === 0) continue;

                const candidates = results.map(r => ({
                    id: r.slug,
                    name: r.title || r.slug
                }));

                let bestMatch = null;
                let bestScore = 0;

                for (const candidate of candidates) {
                    for (const t of titlesToTry) {
                        const score = FuzzyMatcher.getSimilarity(t, candidate.name);
                        if (score > bestScore) {
                            bestScore = score;
                            bestMatch = candidate;
                        }
                    }
                }

                console.log(`[Anikoto Local] Search "${searchTitle}" → best: "${bestMatch?.name}" (score: ${bestScore})`);

                if (bestMatch && bestScore > 0.5) {
                    return bestMatch.id; // slug
                }

                // Keyword overlap fallback: if the titles share significant words
                // (handles Japanese↔English title mismatches like "Mairimashita! Iruma-kun" ↔ "Iruma-kun Season 3")
                if (bestMatch && bestScore > 0.3) {
                    const stopWords = new Set(['the', 'a', 'an', 'of', 'in', 'to', 'season', 'part', 'cour']);
                    const extractKeywords = str => str.toLowerCase()
                        .replace(/[!?.,\-:()]/g, ' ')
                        .split(/\s+/)
                        .filter(w => w.length > 2 && !stopWords.has(w));
                    const searchWords = new Set(extractKeywords(searchTitle));
                    const candidateWords = extractKeywords(bestMatch.name);
                    const shared = candidateWords.filter(w => searchWords.has(w));
                    if (shared.length >= 2) {
                        console.log(`[Anikoto Local] Keyword overlap (${shared.join(', ')}) accepted "${bestMatch.name}" for "${searchTitle}"`);
                        return bestMatch.id;
                    }
                }
            } catch (error) {
                if (!error.message?.includes('timeout')) {
                    console.warn(`[Anikoto Local] search error for "${searchTitle}": ${error.message}`);
                }
            }
        }
        return null;
    }

    /**
     * Fetch episode list for a given slug.
     * @param {string} animeId - Anikoto slug
     * @returns {{ id: string, episodes: Array, totalEpisodes: number }}
     */
    async getAnimeById(animeId) {
        try {
            const data = await this.executeWithRetry(() => scrapeAnimeEpisodes(animeId));
            if (!data || !data.episodes) {
                return { id: animeId, episodes: [], totalEpisodes: 0 };
            }

            const rawEps = data.episodes; // [ { number, title, ... } ]
            const episodes = rawEps.map(ep => ({
                id: `${animeId}::${ep.number}`,  // composite ID: slug::epNumber
                number: ep.number,
                title: ep.title || `Episode ${ep.number}`
            }));

            return {
                id: animeId,
                episodes,
                totalEpisodes: episodes.length > 0 ? episodes[episodes.length - 1].number : 0
            };
        } catch (e) {
            console.error(`[Anikoto Local] getAnimeById failed for ${animeId}: ${e.message}`);
            return { id: animeId, episodes: [], totalEpisodes: 0 };
        }
    }

    /**
     * Return available servers for an episode.
     *
     * LIGHTWEIGHT and RESILIENT — directly uses:
     *   1. scrapeAnimeEpisodes (cached by anikoto-api, fast) to get episode dataIds/dataMal/dataTimestamp
     *   2. fetchJson('/ajax/server/list') for the AJAX server name list (just HTML, no HLS extraction)
     *   3. fetchKiwiSources for Kiwi-Stream entries from the mapper API
     *
     * We do NOT use scrapeWatchStream because it throws when ep.dataIds is missing, and
     * we do NOT fall back to getEpisodeSources (which runs scrapeWatch on ALL servers = 45s+).
     *
     * @param {string} episodeId - composite ID "slug::epNumber"
     */
    async getEpisodeServers(episodeId) {
        const separatorIdx = episodeId.lastIndexOf('::');
        if (separatorIdx === -1) {
            return [{ id: episodeId, name: 'Default', cat: 'sub' }];
        }

        const slug = episodeId.slice(0, separatorIdx);
        const epNumber = episodeId.slice(separatorIdx + 2);

        const seen = new Set();
        const servers = [];
        const addServer = (name, cat, linkId = null, isEmbed = false) => {
            const key = `${name}::${cat}`;
            if (seen.has(key)) return;
            seen.add(key);
            servers.push({ id: episodeId, name, cat, linkId, is_embed: isEmbed });
        };

        // ── Cache check ──────────────────────────────────────────────────────
        const cacheKey = episodeId;
        const cached = this._serverListCache.get(cacheKey);
        if (cached && Date.now() - cached.ts < this._serverListCacheTTL) {
            console.log(`[Anikoto Local] getEpisodeServers: cache hit for ${slug} ep ${epNumber} (${cached.servers.length} servers)`);
            return cached.servers;
        }

        try {
            // ── Step 1: Get episode data (cached by anikoto-api) ──────────────
            // Fuzzy number match: "6" matches "06", "6", "6.0", etc.
            const numEp = parseInt(epNumber, 10);
            const rawEpisodeData = await scrapeAnimeEpisodes(slug)
                .then(({ episodes }) => episodes.find(ep => {
                    if (ep.number === epNumber) return true;
                    const n = parseInt(ep.number, 10);
                    return !isNaN(n) && !isNaN(numEp) && n === numEp;
                }))
                .catch(() => null);

            console.log(`[Anikoto Local] getEpisodeServers: ep=${epNumber} dataIds=${rawEpisodeData?.dataIds} dataMal=${rawEpisodeData?.dataMal}`);

            // ── Step 2: Fetch server list via AJAX + parse with cheerio ───────
            // Run in parallel with Kiwi mapper (Step 3)
            const [serverListResult, kiwiResult] = await Promise.allSettled([
                // Server list AJAX (with 2 retries)
                (async () => {
                    if (!rawEpisodeData?.dataIds) {
                        console.warn(`[Anikoto Local] getEpisodeServers: ep ${epNumber} has no dataIds — skipping AJAX server list`);
                        return [];
                    }
                    for (let attempt = 0; attempt <= 2; attempt++) {
                        try {
                            const listData = await fetchJson(`/ajax/server/list?servers=${rawEpisodeData.dataIds}`, {
                                Referer: `https://anikoto.net/watch/${slug}/ep-${epNumber}`
                            });
                            if (!listData?.status || !listData?.result) {
                                if (attempt < 2) {
                                    await new Promise(r => setTimeout(r, 400));
                                    continue;
                                }
                                console.warn(`[Anikoto Local] getEpisodeServers: AJAX server list returned empty (status=${listData?.status})`);
                                return [];
                            }
                            // Parse the HTML with cheerio to extract server name/type/linkId
                            const cheerio = require('cheerio');
                            const $ = cheerio.load(listData.result);
                            const parsed = [];
                            $('.server, li').each((_, el) => {
                                const $el = $(el);
                                const linkId = $el.attr('data-link-id');
                                if (!linkId) return;
                                const serverName = $el.text().trim();
                                const $typeContainer = $el.closest('.type');
                                const typeLabel = $typeContainer.find('label, .name').text().trim().toLowerCase() || 'sub';
                                parsed.push({ id: linkId, name: serverName, type: typeLabel });
                            });

                            // ── Parse download links from mapper-dl-row ──────────────
                            // New anikoto UI (Aug 2026): per-quality download chips grouped
                            // under .mapper-dl-grp with server name in .mapper-dl-grp-toggle
                            const parsedDownloads = [];
                            $('.mapper-dl-row').each((_, row) => {
                                $(row).find('.mapper-dl-grp').each((_, grp) => {
                                    const $grp = $(grp);
                                    const groupName = $grp.find('.mapper-dl-grp-toggle').first().text().trim();
                                    const isDub = /dub/i.test(groupName);
                                    const serverName = groupName.replace(/\s*(sub|dub)\s*$/i, '').trim();
                                    $grp.find('.mapper-dl-grp-items .mapper-dl-chip').each((_, link) => {
                                        const $link = $(link);
                                        const href = $link.attr('href');
                                        const resolution = $link.text().trim(); // e.g. "360p"
                                        if (href && href !== '#') {
                                            parsedDownloads.push({ downloadPage: href, server: serverName, resolution, isDub });
                                        }
                                    });
                                });
                            });
                            if (parsedDownloads.length > 0) {
                                console.log(`[Anikoto Local] getEpisodeServers: ${parsedDownloads.length} download links found in HTML`);
                                this._downloadCache.set(cacheKey, parsedDownloads);
                            }

                            console.log(`[Anikoto Local] getEpisodeServers: AJAX returned ${parsed.length} server entries`);
                            return parsed;
                        } catch (ajaxErr) {
                            if (attempt < 2) {
                                console.warn(`[Anikoto Local] getEpisodeServers: AJAX attempt ${attempt + 1} failed (${ajaxErr.message}), retrying in 400ms...`);
                                await new Promise(r => setTimeout(r, 400));
                            } else {
                                console.warn(`[Anikoto Local] getEpisodeServers: AJAX fetchJson failed — ${ajaxErr.message}`);
                                return [];
                            }
                        }
                    }
                    return [];
                })(),

                // Kiwi mapper
                (async () => {
                    if (!rawEpisodeData?.dataMal || !rawEpisodeData?.dataTimestamp) return { sources: [], downloads: [] };
                    const result = await fetchKiwiSources(
                        rawEpisodeData.dataMal, epNumber, rawEpisodeData.dataTimestamp
                    ).catch(() => ({ sources: [], downloads: [] }));
                    const { sources = [], downloads = [] } = result;
                    console.log(`[Anikoto Local] getEpisodeServers: ${sources.length} Kiwi stream entries, ${downloads.length} Kiwi download links`);
                    return { sources, downloads };
                })(),
            ]);

            // ── Step 3: Add regular servers ───────────────────────────────────
            if (serverListResult.status === 'rejected') {
                console.warn(`[Anikoto Local] getEpisodeServers: AJAX server list IIFE rejected — ${serverListResult.reason?.message}`);
            }
            if (kiwiResult.status === 'rejected') {
                console.warn(`[Anikoto Local] getEpisodeServers: Kiwi mapper IIFE rejected — ${kiwiResult.reason?.message}`);
            }
            const rawServers = serverListResult.status === 'fulfilled' ? serverListResult.value : [];
            for (const s of rawServers) {
                if (!s.name) continue;
                let cat = (s.type || 'sub').toLowerCase();
                if (cat === 'a-dub') cat = 'dub';
                else if (cat === 'h-sub' || cat === 'hsub' || cat === 'softsub') cat = 'sub';
                addServer(s.name, cat, s.id || null, false);
                addServer(`${s.name}-Embed`, cat, s.id || null, true);
            }

            // ── Step 4: Add Kiwi-Stream servers ──────────────────────────────
            const kiwiData = kiwiResult.status === 'fulfilled' ? kiwiResult.value : { sources: [], downloads: [] };
            const kiwiEntries = Array.isArray(kiwiData) ? kiwiData : (kiwiData.sources || []);
            const kiwiDownloads = Array.isArray(kiwiData) ? [] : (kiwiData.downloads || []);

            // Merge HTML-parsed downloads (from AJAX) + Kiwi mapper downloads
            // Note: the HTML-parsed ones are already in _downloadCache (set inside the AJAX IIFE).
            // Merge in the Kiwi downloads too so the cache has all sources.
            const existingHtmlDownloads = this._downloadCache.get(cacheKey) || [];
            const mergedDownloads = [...existingHtmlDownloads, ...kiwiDownloads];
            if (mergedDownloads.length > 0) {
                console.log(`[Anikoto Local] getEpisodeServers: ${existingHtmlDownloads.length} HTML + ${kiwiDownloads.length} Kiwi = ${mergedDownloads.length} total download links cached`);
                this._downloadCache.set(cacheKey, mergedDownloads);
            } else {
                console.log(`[Anikoto Local] getEpisodeServers: 0 download links found (no mapper-dl-row in AJAX HTML and Kiwi mapper empty)`);
            }

            for (const entry of kiwiEntries) {
                const cat = entry.cat || 'sub';
                addServer('Kiwi-Stream', cat, entry.linkId, false);
                addServer('Kiwi-Stream-Embed', cat, entry.linkId, true);
            }

            if (servers.length > 0) {
                console.log(`[Anikoto Local] getEpisodeServers: ${servers.length} servers for ${slug} ep ${epNumber}`);
                // Store in cache so subsequent navigations are instant
                this._serverListCache.set(cacheKey, { servers, ts: Date.now() });
                return servers;
            }

            // ── Nothing found at all ──────────────────────────────────────────
            console.warn(`[Anikoto Local] getEpisodeServers: 0 servers for ${slug} ep ${epNumber} — returning Default`);
            return [{ id: episodeId, name: 'Default', cat: 'sub' }];

        } catch (e) {
            console.warn('[Anikoto Local] getEpisodeServers error:', e.message);
            return [{ id: episodeId, name: 'Default', cat: 'sub' }];
        }
    }

    /**
     * Return cached download links for an episode (populated by getEpisodeServers).
     * Falls back to an empty array if the server list hasn't been fetched yet.
     */
    getEpisodeDownloads(episodeId) {
        return this._downloadCache.get(episodeId) || [];
    }

    /**
     * When serverId is provided, filters to only that server's sources.
     * When category is provided, filters to only sub or dub sources.
     * Quality is set to 'auto' so servers appear as server buttons, not quality options.
     *
     * @param {string} episodeId - composite "slug::epNumber"
     * @param {string} [serverId] - optional server name to filter by (e.g. "HD-1", "Vidstream-2")
     * @param {string} [category] - 'sub' or 'dub' (default: 'sub')
     */
    async getEpisodeSources(episodeId, serverId = null, category = null) {
        let kiwiLinkId = null;
        if (serverId && serverId.includes('|kiwiLinkId=')) {
            const parts = serverId.split('|kiwiLinkId=');
            serverId = parts[0];
            kiwiLinkId = parts[1];
        }
        // Parse the composite ID back into slug + episode number
        const separatorIdx = episodeId.lastIndexOf('::');
        if (separatorIdx === -1) {
            throw new Error(`[Anikoto Local] Invalid episodeId format: ${episodeId}`);
        }
        const slug = episodeId.slice(0, separatorIdx);
        const epNumber = episodeId.slice(separatorIdx + 2);

        try {
            // ── KIWI-STREAM FAST PATH ─────────────────────────────────────────────────
            // Kiwi-Stream is NOT in the regular /ajax/server/list. It requires its own
            // mapper API lookup. When the user selects Kiwi-Stream, skip scrapeWatch
            // entirely to avoid 50+ seconds of other-server extraction timeouts.
            const kiwiServerName = 'Kiwi-Stream';
            const isKiwiEmbed = serverId === `${kiwiServerName}-Embed`;
            if (serverId === kiwiServerName || isKiwiEmbed) {
                const sources = [];
                
                if (kiwiLinkId) {
                    // We were passed the linkId directly from the frontend UI! Instant resolve.
                    console.log(`[Anikoto Local] Kiwi fast-path: Resolving linkId directly ${kiwiLinkId}`);
                    try {
                        const serverData = await fetchJson(`/ajax/server?get=${kiwiLinkId}`, {
                            Referer: `https://anikoto.net/watch/${slug}/ep-${epNumber}`
                        });
                        console.log(`[Anikoto Local] Kiwi server response (direct):`, JSON.stringify(serverData)?.slice(0, 200));

                        if (serverData?.status && serverData?.result?.url) {
                            const kiwiReferer = 'https://anikoto.net/';
                            const hls = await resolveKiwiHLS(serverData.result.url, kiwiReferer);

                            if (!isKiwiEmbed) {
                                // HLS button clicked — return HLS if available, else embed fallback
                                if (hls) {
                                    console.log(`[Anikoto Local] Kiwi HLS decoded: ${hls.m3u8}`);
                                    // Expand allSources into individual quality entries (360p, 720p, 1080p)
                                    // so the quality picker gets all options — NOT a single nested object.
                                    if (hls.allSources && hls.allSources.length > 1) {
                                        for (const qs of hls.allSources) {
                                            sources.push({
                                                url: qs.url,
                                                quality: qs.quality,
                                                serverName: kiwiServerName,
                                                isM3U8: true,
                                                linkId: kiwiLinkId,
                                                cat: category,
                                                embed: hls.referer,
                                            });
                                        }
                                    } else {
                                        sources.push({
                                            url: hls.m3u8,
                                            quality: 'auto',
                                            serverName: kiwiServerName,
                                            isM3U8: true,
                                            linkId: kiwiLinkId,
                                            cat: category,
                                            embed: hls.referer,
                                        });
                                    }
                                } else {
                                    sources.push({
                                        url: serverData.result.url,
                                        quality: 'auto',
                                        serverName: kiwiServerName,
                                        isM3U8: false,
                                        is_embed: true,
                                        linkId: kiwiLinkId,
                                        cat: category,
                                        embed: kiwiReferer,
                                    });
                                }
                            } else {
                                // Embed button clicked — always return the embed source
                                sources.push({
                                    url: serverData.result.url,
                                    quality: 'auto',
                                    serverName: `${kiwiServerName}-Embed`,
                                    isM3U8: false,
                                    is_embed: true,
                                    linkId: kiwiLinkId,
                                    cat: category,
                                    embed: kiwiReferer,
                                });
                            }
                        }
                    } catch (e) {
                        console.warn(`[Anikoto Local] Kiwi-Stream direct source resolution failed: ${e.message}`);
                    }
                } else {
                    // Fallback mapper flow if we didn't receive linkId
                    const rawEpisodeData = await scrapeAnimeEpisodes(slug)
                        .then(({ episodes }) => episodes.find(ep => ep.number === epNumber))
                        .catch(() => null);

                    console.log(`[Anikoto Local] Kiwi fast-path: epData=${JSON.stringify({ dataMal: rawEpisodeData?.dataMal, dataTimestamp: rawEpisodeData?.dataTimestamp })}`);

                    if (rawEpisodeData?.dataMal && rawEpisodeData?.dataTimestamp) {
                        const { sources: kiwiEntries } = await fetchKiwiSources(rawEpisodeData.dataMal, epNumber, rawEpisodeData.dataTimestamp);
                        console.log(`[Anikoto Local] Kiwi fast-path: ${kiwiEntries.length} mapper entries`);

                        await Promise.all(kiwiEntries.map(async (entry) => {
                            if (category && entry.cat !== category) return;

                            try {
                                const serverData = await fetchJson(`/ajax/server?get=${entry.linkId}`, {
                                    Referer: `https://anikoto.net/watch/${slug}/ep-${epNumber}`
                                });

                                if (serverData?.status && serverData?.result?.url) {
                                    const kiwiReferer = 'https://anikoto.net/';
                                    const hls = await resolveKiwiHLS(serverData.result.url, kiwiReferer);
                                    if (!isKiwiEmbed) {
                                        if (hls) {
                                            // Expand allSources into individual quality entries
                                            if (hls.allSources && hls.allSources.length > 1) {
                                                for (const qs of hls.allSources) {
                                                    sources.push({
                                                        url: qs.url,
                                                        quality: qs.quality,
                                                        serverName: kiwiServerName,
                                                        isM3U8: true,
                                                        linkId: entry.linkId,
                                                        cat: entry.cat,
                                                        embed: hls.referer,
                                                    });
                                                }
                                            } else {
                                                sources.push({
                                                    url: hls.m3u8,
                                                    quality: 'auto',
                                                    serverName: kiwiServerName,
                                                    isM3U8: true,
                                                    linkId: entry.linkId,
                                                    cat: entry.cat,
                                                    embed: hls.referer,
                                                });
                                            }
                                        } else {
                                            sources.push({
                                                url: serverData.result.url,
                                                quality: 'auto',
                                                serverName: kiwiServerName,
                                                isM3U8: false,
                                                is_embed: true,
                                                linkId: entry.linkId,
                                                cat: entry.cat,
                                                embed: kiwiReferer,
                                            });
                                        }
                                    } else {
                                        sources.push({
                                            url: serverData.result.url,
                                            quality: 'auto',
                                            serverName: `${kiwiServerName}-Embed`,
                                            isM3U8: false,
                                            is_embed: true,
                                            linkId: entry.linkId,
                                            cat: entry.cat,
                                            embed: kiwiReferer,
                                        });
                                    }
                                }
                            } catch (e) { }
                        }));
                    }
                }

                console.log(`[Anikoto Local] ${sources.length} sources for ${slug} ep ${epNumber} (cat:${category}, server:${serverId}) (${sources.filter(s => s.isM3U8).length} HLS, ${sources.filter(s => s.is_embed).length} embed)`);
                return { sources, subtitles: [], intro: null, outro: null };
            }
            // ──────────────────────────────────────────────────────────────────────────

            // ── UNIVERSAL SERVER FAST-PATH ────────────────────────────────────────────
            // When the frontend passes |linkId=X for any non-Kiwi server, we skip
            // scrapeWatch (which runs all servers serially with 15s per timeout).
            // Flow:
            //   1. /ajax/server?get=linkId  → embed URL (~1s, always works)
            //   2. scrapeWatchStream         → HLS sources (~3-8s, works for most shows)
            //   3. Normalize 'a-dub'→'dub', filter for requested category + server
            //   4. If HLS found  → return HLS + embed together
            //   5. If HLS fails  → DON'T return embed early; fall through to scrapeWatch
            //      (scrapeWatch calls extractVidstream internally which may still succeed)
            let serverLinkId = null;
            if (serverId && serverId.includes('|linkId=')) {
                const parts = serverId.split('|linkId=');
                serverId = parts[0];
                serverLinkId = parts[1];
            }

            if (serverId && serverLinkId) {
                const isEmbed = serverId.endsWith('-Embed');
                const baseServerName = isEmbed ? serverId.replace(/-Embed$/, '') : serverId;

                try {
                    console.log(`[Anikoto Local] Universal fast-path: ${baseServerName} linkId=${serverLinkId.slice(0, 20)}...`);
                    const serverData = await Promise.race([
                        fetchJson(`/ajax/server?get=${serverLinkId}`, {
                            Referer: `https://anikoto.net/watch/${slug}/ep-${epNumber}`
                        }),
                        new Promise((_, reject) => setTimeout(() => reject(new Error('AJAX timeout')), 8000))
                    ]);

                    if (serverData?.status && serverData?.result?.url) {
                        const embedUrl = serverData.result.url;
                        const refererUrl = 'https://anikoto.net/';

                        // Fetch HLS stream AND downloads concurrently.
                        // The download branch only runs if _downloadCache is empty (race condition
                        // where getEpisodeSources ran before getEpisodeServers had a chance to
                        // populate the cache). scrapeAnimeEpisodes is cached by anikoto-api so it
                        // resolves instantly on subsequent calls.
                        const downloadFetchNeeded = this._downloadCache.get(episodeId)?.length === 0
                            || !this._downloadCache.has(episodeId);

                        const [streamResult, fetchedDownloads] = await Promise.all([
                            // 1. HLS extraction (primary)
                            isEmbed ? Promise.resolve(null) : extractStreamDirect(embedUrl, refererUrl),

                            // 2. Download fallback fetch (only if cache is empty)
                            downloadFetchNeeded
                                ? scrapeAnimeEpisodes(slug)
                                    .then(({ episodes }) => {
                                        const numEp = parseInt(epNumber, 10);
                                        return episodes.find(ep => ep.number === epNumber
                                            || (!isNaN(numEp) && parseInt(ep.number, 10) === numEp));
                                    })
                                    .then(epData => {
                                        if (!epData?.dataMal || !epData?.dataTimestamp) return [];
                                        return fetchKiwiSources(epData.dataMal, epNumber, epData.dataTimestamp)
                                            .then(r => r.downloads || []).catch(() => []);
                                    })
                                    .catch(() => [])
                                : Promise.resolve(null),
                        ]);

                        // Populate download cache if we fetched something new
                        if (Array.isArray(fetchedDownloads) && fetchedDownloads.length > 0) {
                            const htmlDownloads = this._downloadCache.get(episodeId) || [];
                            const merged = [...htmlDownloads, ...fetchedDownloads];
                            console.log(`[Anikoto Local] Fast-path: fetched ${fetchedDownloads.length} Kiwi download links (cache miss fallback)`);
                            this._downloadCache.set(episodeId, merged);
                        }

                        if (isEmbed) {
                            // Embed button explicitly clicked — return iframe immediately
                            console.log(`[Anikoto Local] 1 sources for ${slug} ep ${epNumber} (fast-path:${serverId}) (0 HLS, 1 embed)`);
                            return {
                                sources: [{
                                    url: embedUrl,
                                    quality: 'auto',
                                    serverName: serverId,
                                    isM3U8: false,
                                    is_embed: true,
                                    linkId: serverLinkId,
                                    cat: category || 'sub',
                                    embed: refererUrl,
                                }],
                                subtitles: [],
                                intro: null,
                                outro: null,
                                downloads: this.getEpisodeDownloads(episodeId),
                            };
                        }

                        // streamResult was already set by the concurrent Promise.all above.
                        // Fallback: if direct extraction fails (e.g. new embed host pattern),
                        // try scrapeWatch once with a 10s timeout as a last resort.
                        if (!streamResult) {
                            console.warn(`[Anikoto Local] Fast-path: direct extraction failed for ${baseServerName}, trying scrapeWatch fallback...`);
                            try {
                                const streamData = await Promise.race([
                                    scrapeWatch(slug, epNumber),
                                    new Promise((_, reject) => setTimeout(() => reject(new Error('scrapeWatch timeout')), 10000))
                                ]);
                                // Build a pseudo-streamResult from scrapeWatch data
                                const s = (streamData?.sources || []).find(s => {
                                    const sn = (s.server || s.serverName || '').toLowerCase();
                                    return !baseServerName || sn.includes(baseServerName.split('-')[0].toLowerCase());
                                });
                                if (s) {
                                    const m3u8Url = s.m3u8 || (s.file?.includes?.('.m3u8') ? s.file : null);
                                    if (m3u8Url) {
                                        streamResult = { m3u8: m3u8Url, referer: s.referer || refererUrl, tracks: [] };
                                    }
                                }
                            } catch (swErr) {
                                console.warn(`[Anikoto Local] Fast-path: scrapeWatch fallback also failed (${swErr.message})`);
                            }
                        }

                        if (streamResult?.m3u8) {
                            const hlsSources = [];
                            // Build quality variants if available
                            if (streamResult.allSources && streamResult.allSources.length > 1) {
                                for (const qs of streamResult.allSources) {
                                    hlsSources.push({
                                        url: qs.url,
                                        quality: qs.quality,
                                        serverName: baseServerName,
                                        isM3U8: true,
                                        linkId: serverLinkId,
                                        cat: category || 'sub',
                                        embed: streamResult.referer || refererUrl,
                                    });
                                }
                            } else {
                                hlsSources.push({
                                    url: streamResult.m3u8,
                                    quality: 'auto',
                                    serverName: baseServerName,
                                    isM3U8: true,
                                    linkId: serverLinkId,
                                    cat: category || 'sub',
                                    embed: streamResult.referer || refererUrl,
                                });
                            }

                            // Build subtitle list from extracted tracks.
                            // Include the embed referer so the frontend can pass it to the
                            // segment proxy — CDNs like vidtub.norami.top enforce hotlink
                            // protection and return 403 without the correct Referer header.
                            const subtitles = (streamResult.tracks || []).map(t => ({
                                url: t.file || t.url || '',
                                label: t.label || t.kind || 'Unknown',
                                kind: t.kind || 'captions',
                                default: t.default || false,
                                referer: streamResult.referer || '',
                            }));


                            console.log(`[Anikoto Local] ${hlsSources.length} HLS sources for ${slug} ep ${epNumber} (fast-path:${baseServerName})`);
                            return {
                                sources: hlsSources,
                                subtitles,
                                intro: streamResult.intro || null,
                                outro: streamResult.outro || null,
                                downloads: this.getEpisodeDownloads(episodeId),
                            };
                        }

                        // All extraction methods failed — return transient empty so the controller
                        // doesn't cache this failure and the frontend retries cleanly.
                        console.log(`[Anikoto Local] Fast-path: no HLS for ${baseServerName} — returning empty sources for clean server separation`);
                        return {
                            sources: [],
                            subtitles: [],
                            intro: null,
                            outro: null,
                            transient: true, // Don't cache — extraction may succeed on next request
                        };

                    }
                } catch (e) {
                    console.warn(`[Anikoto Local] Universal fast-path AJAX failed (${e.message})`);
                }
                // Falls through to scrapeWatch below
            }
            // ──────────────────────────────────────────────────────────────────────────


            // Run scrapeWatch and the Kiwi mapper lookup in parallel

            const [data, rawEpisodeData] = await Promise.all([
                this.executeWithRetry(() => scrapeWatch(slug, epNumber, category)),
                scrapeAnimeEpisodes(slug).then(({ episodes }) => episodes.find(ep => ep.number === epNumber)).catch(() => null),
            ]);

            if (!data || !data.sources) {
                return { sources: [] };
            }

            const rawSources = data.sources;
            let selectedTracks = [];
            const sources = [];

            for (const s of rawSources) {
                const serverName = s.server || 'Default';
                let cat = s.type || 'sub';
                
                // Map a-dub and h-sub to standard sub/dub
                const lowerCat = cat.toLowerCase();
                if (lowerCat === 'a-dub') {
                    cat = 'dub';
                } else if (lowerCat === 'h-sub' || lowerCat === 'hsub') {
                    cat = 'sub';
                }
                const referer = s.referer || STREAM_REFERER;

                // Filter by requested category if provided
                if (category && cat !== category) continue;

                // If serverId is specified, filter by server name only.
                // Category filter above already handles sub/dub disambiguation.
                const isRequestedEmbed = serverId && serverId.endsWith('-Embed');
                const baseServerId = serverId ? serverId.replace('-Embed', '') : null;
                
                if (serverId && serverName !== baseServerId) continue;

                // Capture tracks for the matching source
                if (s.tracks && s.tracks.length > 0) {
                    selectedTracks = s.tracks;
                }

                // 1. HLS source — preferred
                if (s.m3u8 && s.m3u8.includes('.m3u8') && (!serverId || !isRequestedEmbed)) {
                    if (s.allSources && s.allSources.length > 1) {
                        // Provider returned multiple quality levels — expand each as a separate source
                        for (const qs of s.allSources) {
                            sources.push({
                                url: qs.url,
                                quality: qs.quality,
                                serverName,
                                isM3U8: true,
                                cat,
                                embed: referer
                            });
                        }
                    } else {
                        sources.push({
                            url: s.m3u8,
                            quality: 'auto',
                            serverName,
                            isM3U8: true,
                            cat,
                            embed: referer
                        });
                    }
                }
                
                // 2. Embed source
                // Only add embed when: no specific server requested (general load), or
                // user explicitly clicked the -Embed variant of a server.
                // Do NOT add embed when user clicked an HLS server button — if HLS
                // extraction failed (vidtube cold-start timeout), return nothing clean
                // so the frontend shows a proper "retry" state rather than silently
                // switching to iframe.
                if (s.url && (!serverId || isRequestedEmbed)) {
                    sources.push({
                        url: s.url,
                        quality: 'auto',
                        serverName: `${serverName}-Embed`,
                        isM3U8: false,
                        is_embed: true,
                        cat,
                        embed: referer
                    });
                }
            }

            let allDownloads = [...(data.downloads || [])];

            // Always fetch download links from the mapper API (regardless of selected server).
            // The streaming source resolution is only done when wantKiwi is true.
            const isKiwiEmbedRegular = serverId === `${kiwiServerName}-Embed`;
            const wantKiwi = !serverId || serverId === kiwiServerName || isKiwiEmbedRegular;
            if (rawEpisodeData?.dataMal && rawEpisodeData?.dataTimestamp) {
                const { sources: kiwiEntries, downloads: kiwiDownloads } = await fetchKiwiSources(rawEpisodeData.dataMal, epNumber, rawEpisodeData.dataTimestamp);
                
                // Always merge download portals
                allDownloads.push(...kiwiDownloads);

                // Only resolve Kiwi embed URLs if we actually want Kiwi stream sources
                if (wantKiwi) {
                    const kiwiReferer = 'https://anikoto.net/';
                    await Promise.all(kiwiEntries.map(async (entry) => {
                        if (category && entry.cat !== category) return;
                        try {
                            const serverData = await fetchJson(`/ajax/server?get=${entry.linkId}`, {
                                Referer: `${kiwiReferer}watch/${slug}/ep-${epNumber}`
                            });
                            if (serverData?.status && serverData?.result?.url) {
                                const hls = await resolveKiwiHLS(serverData.result.url, kiwiReferer);
                                // Always push HLS source (if extracted)
                                if (hls && !isKiwiEmbedRegular) {
                                    sources.push({
                                        url: hls.m3u8,
                                        quality: hls.allSources?.[0]?.quality || 'auto',
                                        serverName: kiwiServerName,
                                        isM3U8: true,
                                        linkId: entry.linkId,
                                        cat: entry.cat,
                                        embed: hls.referer,
                                        allSources: hls.allSources,
                                    });
                                }
                                // Always push embed source too
                                if (!serverId || isKiwiEmbedRegular) {
                                    sources.push({
                                        url: serverData.result.url,
                                        quality: 'auto',
                                        serverName: `${kiwiServerName}-Embed`,
                                        isM3U8: false,
                                        is_embed: true,
                                        linkId: entry.linkId,
                                        cat: entry.cat,
                                        embed: kiwiReferer,
                                    });
                                }
                            }
                        } catch (e) {
                            console.warn(`[Anikoto Local] Kiwi-Stream source resolution failed (${entry.cat}): ${e.message}`);
                        }
                    }));
                }
            }

            console.log(`[Anikoto Local] ${sources.length} sources for ${slug} ep ${epNumber} (cat:${category}${serverId ? `, server:${serverId}` : ''}) (${sources.filter(s => s.isM3U8).length} HLS, ${sources.filter(s => s.is_embed).length} embed)`);

            const intro = data.skip_data?.intro ? data.skip_data.intro : null;
            const outro = data.skip_data?.outro ? data.skip_data.outro : null;

            return {
                sources,
                subtitles: selectedTracks,
                intro: intro,
                outro: outro,
                downloads: allDownloads
            };
        } catch (e) {
            console.error(`[Anikoto Local] getEpisodeSources failed: ${e.message}`);
            return { sources: [] };
        }
    }

}

module.exports = new AnikotoProvider();

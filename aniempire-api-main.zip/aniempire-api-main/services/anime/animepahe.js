const animepahe = require('animepahe-api');
const FuzzyMatcher = require('../../utils/fuzzyMatcher');
const path = require('path');

// Redirect cookie storage to a persistent folder inside aniempire-api's
// own data directory. This survives npm installs and reinstalls.
const ANIMEPAHE_DATA_DIR = path.join(__dirname, '../../data/animepahe');
animepahe.Config.dataDir = ANIMEPAHE_DATA_DIR;
// Refresh cookies every 2 days — CF clearance tokens become stale faster than the
// library's default 14-day interval, causing "cookies may be stale" errors.
animepahe.Config.cookiesRefreshInterval = 2 * 24 * 60 * 60 * 1000;

class AnimePahe {
    constructor() {
        this.name = 'animepahe';
        this.initPromise = this._initLibrary();
    }

    async _initLibrary() {
        try {
            const proxyService = require('../proxyService');
            const proxies = proxyService.getAllProxies();
            if (proxies && proxies.length > 0) {
                animepahe.Config.updateProxies(proxies);
                animepahe.Config.proxyEnabled = true;
                console.log(`[AnimePahe] Library initialized with ${proxies.length} proxy configs.`);
            }
            console.log(`[AnimePahe] Using data dir: ${ANIMEPAHE_DATA_DIR}`);
            // Initialize cookies synchronously (load from disk, no network call)
            await animepahe.initialize().catch(() => {});
            // Validate cookies in the BACKGROUND — don't block initPromise.
            // CF clearance is session-bound (TLS fingerprint), so after a server
            // restart the old cookie may be stale even within the 2-day interval.
            // Firing this as a background job means user requests are never held
            // up at startup; the library's built-in retry handles any stale-cookie
            // error on the first real request if the background job hasn't finished.
            setTimeout(() => this._validateCookiesInBackground().catch(() => {}), 500);
            return true;
        } catch (e) {
            console.error('[AnimePahe] Library init failed:', e.message);
            return false;
        }
    }

    async _validateCookiesInBackground() {
        const fs = require('fs');
        const cookiesPath = path.join(ANIMEPAHE_DATA_DIR, 'cookies.json');

        // No cookies at all — refresh immediately in background
        if (!fs.existsSync(cookiesPath)) {
            console.log('[AnimePahe] No cookies found. Running fresh CF bypass in background...');
            await animepahe.Animepahe.refreshCookies();
            console.log('[AnimePahe] Background CF bypass: DONE ✓');
            return;
        }

        // Validate with a real ping using a short timeout so we don't hog the event loop
        try {
            console.log('[AnimePahe] Background: validating cookies with a test ping...');
            const result = await Promise.race([
                animepahe.search('one piece', 1),
                new Promise((_, rej) => setTimeout(() => rej(new Error('validation timeout')), 20000))
            ]);
            console.log('[AnimePahe] Background cookie validation: PASSED ✓');
        } catch (err) {
            const isStale = err.statusCode === 503 ||
                err.statusCode === 403 ||
                err.message?.toLowerCase().includes('stale') ||
                err.message?.toLowerCase().includes('anti-bot') ||
                err.message?.toLowerCase().includes('challenge') ||
                err.message?.toLowerCase().includes('cookies may be');
            if (isStale) {
                console.warn('[AnimePahe] Background: cookies are stale (new TLS session). Forcing refresh...');
                try { fs.unlinkSync(cookiesPath); } catch {}
                await animepahe.Animepahe.refreshCookies();
                // Give the new cf_clearance ~2s to fully bind before the next
                // gotScraping request fires — the cookie is written to disk but
                // the library's in-memory Config.cookies may lag by one tick.
                await new Promise(r => setTimeout(r, 2000));
                console.log('[AnimePahe] Background cookie refresh: DONE ✓');
            } else {
                console.warn(`[AnimePahe] Background validation ping failed (${err.message}). Proceeding with existing cookies.`);
            }
        }
    }

    isChallenge(error) {
        if (!error) return false;
        const msg = (error.message || '').toLowerCase();
        const code = error.statusCode || error.response?.status;
        return code === 503 || code === 403 ||
            msg.includes('anti-bot') ||
            msg.includes('challenge') ||
            msg.includes('cookies may be stale') ||
            msg.includes('circuit open');
    }

    async executeProviderRequestWithRetry(requestFn, providerName = 'animepahe', retries = 3) {
        await this.initPromise; // Ensure library is ready
        for (let attempt = 0; attempt <= retries; attempt++) {
            try {
                return await requestFn();
            } catch (error) {
                if (this.isLogicalFailure(error)) throw error;
                // For anti-bot/challenge errors the library already performs one internal
                // refresh-and-retry. Adding outer retries on top races against that
                // internal cycle and causes double-refresh conflicts. Surface the error
                // immediately so the orchestrator can fall through to the next provider.
                if (this.isChallenge(error)) throw error;
                if (attempt === retries) throw error;
                const totalDelay = (2000 * Math.pow(1.5, attempt)) + (Math.random() * 1000);
                await this.delay(totalDelay);
            }
        }
    }

    isLogicalFailure(error) {
        if (!error || !error.message) return false;
        const msg = error.message.toLowerCase();
        const status = error.response?.status;
        return status === 404 || msg.includes('not found') || msg.includes('does not exist') || msg.includes('no search results found');
    }

    delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

    async search(title, page = 1) {
        try {
            const results = await this.executeProviderRequestWithRetry(() => animepahe.search(title));
            return { results: results.data || results };
        } catch (error) {
            console.error('AnimePahe search error:', error.message);
            return { results: [] };
        }
    }

    async resolveAnimeId(title, altTitles = [], malId, anilistId) {
        const isJapanese = (str) => /[\u3000-\u303f\u3040-\u309f\u30a0-\u30ff\uff00-\uff9f\u4e00-\u9faf\u3400-\u4dbf]/.test(str);
        const allTitles = [title, ...altTitles].filter(Boolean);
        
        // Reorder search queries: prioritize English/Romaji over Japanese characters to avoid wasting search budget
        const nonJpTitles = allTitles.filter(t => !isJapanese(t));
        const jpTitles = allTitles.filter(t => isJapanese(t));
        const sortedTitles = [...new Set([...nonJpTitles, ...jpTitles])];
        
        const titlesToTry = sortedTitles.slice(0, 4); // Limit title search attempts to 4 to prevent API timeouts
        const totalStart = Date.now();
        const TOTAL_BUDGET_MS = 60000; // 60s total budget for ALL title attempts
        const PER_SEARCH_TIMEOUT = 25000; // 25s per individual search
        // How long to wait after a challenge before retrying the next title.
        // The library's internal refreshCookies() + gotScraping re-request typically
        // takes 30-60s (browser launch + CF solve). We only wait here if the previous
        // title attempt was a challenge but NOT a circuit-open (circuit-open means the
        // browser skipped entirely and the error is instant, so no wait needed).
        const CHALLENGE_SETTLE_MS = 8000;

        // Track the globally best candidate across ALL searches — used as a fallback
        // when no single search hits the strict 0.6 threshold (e.g. Japanese MAL title
        // vs AnimePahe's English title: "Mairimashita! Iruma-kun" → "Welcome to Demon
        // School! Iruma-kun" scores ~0.4 but is clearly the correct match).
        let globalBestMatch = null;
        let globalBestScore = 0;
        let globalBestSearchTitle = null;
        let lastChallengeAt = null; // timestamp of the most recent challenge error
        
        for (const searchTitle of titlesToTry) {
            // Check if we've exceeded our total budget
            const elapsed = Date.now() - totalStart;
            if (elapsed >= TOTAL_BUDGET_MS) {
                console.log(`[AnimePahe] Total timeout budget (${TOTAL_BUDGET_MS}ms) exceeded after ${elapsed}ms. Giving up.`);
                break;
            }

            // If the previous search hit a challenge, wait a bit for the library's
            // internal refresh-and-retry to fully settle before we fire another search.
            // Without this, successive title attempts land in the same stale-cookie
            // window and all fail identically before the browser finishes the CF solve.
            if (lastChallengeAt !== null) {
                const sinceChallenge = Date.now() - lastChallengeAt;
                if (sinceChallenge < CHALLENGE_SETTLE_MS) {
                    const wait = CHALLENGE_SETTLE_MS - sinceChallenge;
                    console.log(`[AnimePahe] Waiting ${wait}ms for cookie refresh to settle before next title search...`);
                    await this.delay(wait);
                }
                lastChallengeAt = null; // reset — only wait once per challenge event
            }
            
            const remainingBudget = TOTAL_BUDGET_MS - (Date.now() - totalStart);
            if (remainingBudget <= 0) break;
            const searchTimeout = Math.min(PER_SEARCH_TIMEOUT, remainingBudget);
            
            try {
                // Use a tight timeout per search — if AnimePahe's DDoS-Guard is slow, move to the next title.
                // No outer retries here: isChallenge errors short-circuit immediately (the library
                // already handles one internal refresh + retry), and non-challenge errors on a
                // search are not worth retrying across multiple title variations.
                const searchResults = await Promise.race([
                    this.executeProviderRequestWithRetry(() => animepahe.search(searchTitle), 'animepahe', 0),
                    new Promise((_, reject) => setTimeout(() => reject(new Error('search timeout')), searchTimeout))
                ]);
                const results = searchResults.data || searchResults;
                const rCount = results?.length || 0;
                console.log(`[AnimePahe] Search for "${searchTitle}" returned ${rCount} results.`);

                if (!results || results.length === 0) continue;
                
                const candidates = results.map(r => ({
                    id: r.session || r.id,
                    name: r.title || r.name || 'Unknown',
                    type: r.type,
                    status: r.status
                }));

                console.log(`[AnimePahe] Candidates: ${candidates.map(c => c.name).join(', ')}`);

                let bestMatch = null;
                let bestScore = 0;

                // Compare candidates against ALL alternative titles (not just the sliced titlesToTry)
                // to allow matches on English titles that were excluded from the search attempt list.
                for (const candidate of candidates) {
                    for (const t of allTitles) {
                        const score = FuzzyMatcher.getSimilarity(t, candidate.name);
                        if (score > bestScore) {
                            bestScore = score;
                            bestMatch = candidate;
                        }
                    }
                }
                
                console.log(`[AnimePahe] Best match for search "${searchTitle}": "${bestMatch?.name}" (Score: ${bestScore})`);
                
                if (bestMatch && bestScore > 0.6) {
                    return bestMatch.id;
                }

                // Keep track of the globally best candidate for the fallback below
                if (bestMatch && bestScore > globalBestScore) {
                    globalBestScore = bestScore;
                    globalBestMatch = bestMatch;
                    globalBestSearchTitle = searchTitle;
                }
            } catch (error) {
                const isTimeout = error.message?.includes('timeout');
                if (!isTimeout) {
                    console.warn(`[AnimePahe] Search error for "${searchTitle}": ${error.message}`);
                }
                // If this was a challenge error, abort further title searches.
                // Cloudflare is blocking the endpoint — trying alternate titles will only
                // trigger more sequential delays and repeated browser launches.
                if (this.isChallenge(error)) {
                    console.warn(`[AnimePahe] Anti-bot challenge active — aborting remaining title searches.`);
                    break;
                }
            }
        }

        // Fallback: accept the globally best candidate if it scored above 0.4.
        // This handles the case where the MAL primary title is Japanese but AnimePahe
        // stores only the English title — the two share enough tokens (e.g. season
        // number, partial words) to score ~0.35-0.55, below the strict 0.6 but still
        // clearly the right show. False positives from unrelated shows score < 0.3.
        if (globalBestMatch && globalBestScore > 0.4) {
            console.log(`[AnimePahe] Strict threshold not met. Accepting best overall candidate "${globalBestMatch.name}" (Score: ${globalBestScore}) from search "${globalBestSearchTitle}".`);
            return globalBestMatch.id;
        }

        return null;
    }

    async getAnimeById(animeId, targetEpNum = null) {
        // NOTE: We skip animepahe.getInfo() here intentionally.
        // getInfo() does an HTML scrape of the anime page which is CF-protected
        // and often returns "Failed to extract essential anime information" when
        // the session ID is stale or Cloudflare blocks the request.
        // The title field it returns is never used by the orchestrator anyway —
        // only episodes and animeId are consumed from the result.
        
        let page = 1;
        if (targetEpNum) {
            page = Math.ceil(parseInt(targetEpNum) / 30);
            if (page < 1) page = 1;
        }

        const episodesResp = await this.executeProviderRequestWithRetry(() => animepahe.getReleases(animeId, 'episode_asc', page));
        let data = episodesResp.data || [];
        const paginationInfo = episodesResp.paginationInfo || { lastPage: 1 };

        // Self-heal: if target episode isn't in this page, check adjacent pages
        if (targetEpNum && data.length > 0) {
            const hasTarget = data.some(ep => parseInt(ep.episode) === parseInt(targetEpNum));
            if (!hasTarget) {
                const firstInPage = parseInt(data[0].episode);
                const lastInPage = parseInt(data[data.length - 1].episode);
                if (parseInt(targetEpNum) < firstInPage && page > 1) {
                    const prevResp = await this.executeProviderRequestWithRetry(() => animepahe.getReleases(animeId, 'episode_asc', page - 1));
                    data = [...(prevResp.data || []), ...data];
                } else if (parseInt(targetEpNum) > lastInPage && paginationInfo.lastPage > page) {
                    const nextResp = await this.executeProviderRequestWithRetry(() => animepahe.getReleases(animeId, 'episode_asc', page + 1));
                    data = [...data, ...(nextResp.data || [])];
                }
            }
        }

        const episodes = data.map(ep => ({
            id: ep.session,
            number: ep.episode,
            title: `Episode ${ep.episode}`
        }));

        console.log(`[AnimePahe] Found ${episodes.length} episodes. Range: ${episodes[0]?.number} - ${episodes[episodes.length - 1]?.number}`);

        return {
            id: animeId,
            title: 'Unknown', // title not needed by orchestrator — skipping getInfo() saves a CF-protected HTML scrape
            episodes: episodes,
            totalEpisodes: episodesResp.paginationInfo?.total || (episodes.length > 0 ? episodes[episodes.length - 1].number : 0)
        };
    }

    async getEpisodeServers(episodeId, title = null) {
        // Only return sub here. The dub pill is injected by the controller AFTER
        // getEpisodeSources confirms hasDub:true for this specific episode.
        // Emitting dub unconditionally here caused the dub pill to appear even
        // for sub-only anime, and clicking it played sub audio (the bad fallback).
        return [
            { name: 'kwik', id: episodeId, cat: 'sub' },
        ];
    }

    async getEpisodeSources(episodeId, serverId, category = 'sub', animeId = null, title = null, targetEpNum = null) {
        // AnimePahe needs animeSession (animeId) and episodeSession (episodeId)
        // Pass null for category to force resolving ALL download links (both sub and dub)
        let streamingData = await this.executeProviderRequestWithRetry(() => animepahe.getStreamingLinks(animeId, episodeId, true, null));
        
        const mapSources = (data) => (data.sources || []).map(src => {
            const resolution = (src.resolution || '').toLowerCase();
            const audio = (src.audio || '').toLowerCase();
            const isDub = src.isDub || resolution.includes('dub') || audio === 'eng' || audio === 'english';
            return {
                url: src.url,
                quality: src.resolution,
                isM3U8: src.isM3U8 || src.url?.includes('.m3u8'),
                isDub: isDub,
                embed: src.embed || null
            };
        });

        let allSources = mapSources(streamingData);
        let sources = allSources.filter(src => category === 'dub' ? src.isDub === true : src.isDub !== true);

        // SELF-HEAL: If Dub was requested but no Dub sources found, try to resolve a dedicated (Dub) version of the show
        if (category === 'dub' && sources.length === 0 && title && targetEpNum) {
            console.log(`[AnimePahe] No Dub sources in primary ID. Searching for "${title} (Dub)"...`);
            const dubAnimeId = await this.resolveAnimeId(`${title} (Dub)`, [], null, null);
            if (dubAnimeId && dubAnimeId !== animeId) {
                try {
                    const dubInfo = await this.getAnimeById(dubAnimeId, targetEpNum);
                    const dubEp = dubInfo.episodes.find(ep => parseInt(ep.number) === parseInt(targetEpNum));
                    if (dubEp) {
                        console.log(`[AnimePahe] Found Dub session ID: ${dubEp.id}`);
                        // Pass null for category to force resolving ALL download links
                        const dubStreamingData = await this.executeProviderRequestWithRetry(() => animepahe.getStreamingLinks(dubAnimeId, dubEp.id, true, null));
                        const dubSources = mapSources(dubStreamingData);
                        if (dubSources.length > 0) {
                            allSources = dubSources;
                            sources = dubSources;
                            streamingData = dubStreamingData;
                        }
                    }
                } catch (e) {
                    console.error(`[AnimePahe] Failed to fetch Dub sources from dedicated ID: ${e.message}`);
                }
            }
        }

        if (sources.length === 0) {
            // Do NOT fall back to allSources here — that would serve sub audio when dub is requested,
            // making it look like dub worked while actually playing the wrong audio track.
            // Return empty sources; the controller treats this as a clean miss and the frontend
            // can show an appropriate "not available" state.
            console.log(`[AnimePahe] No sources found for category ${category} — returning empty (no fallback to wrong audio).`);
        }
        
        // Build downloads array from the streaming data
        const downloads = (streamingData.downloads || []).map(dl => ({
            quality: dl.quality || `${dl.resolution}p`,
            resolution: dl.resolution,
            url: dl.download || dl.pahe || null,
            downloadPage: dl.downloadPage || null,
            filename: dl.filename || null,
            pahe: dl.pahe || null,
            fansub: dl.fansub || null,
            filesize: dl.filesize || null,
            isDub: dl.isDub || false
        }));

        return { 
            sources, 
            downloads,
            hasDub: allSources.some(s => s.isDub === true),
            hasSub: allSources.some(s => s.isDub !== true)
        };
    }
}

module.exports = new AnimePahe();

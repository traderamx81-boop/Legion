// Read DISABLED_PROVIDERS early — before any provider requires — so disabled
// providers never get imported and their side-effects (browser launches, etc.) never run.
const _disabledAtLoad = (process.env.DISABLED_PROVIDERS || '').split(',').map(s => s.trim().toLowerCase());
const animepahe = _disabledAtLoad.includes('animepahe') ? null : require('./anime/animepahe');
const consumet = require('./anime/consumet');
const megaplay = require('./anime/megaplay');
const anikoto = require('./anime/anikoto');
const animeMappingService = require('./animeMappingService');
const { isDBConnected } = require('../config/db');
const NodeCache = require('node-cache');

const episodeCache = new NodeCache({ stdTTL: 3600 * 24 }); // Cache episodes for 24 hours

class AnimeOrchestrator {
    constructor() {
        const disabled = (process.env.DISABLED_PROVIDERS || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
        const allProviders = [
            { name: 'animepahe', service: animepahe, type: 'direct' },
            { name: 'anikoto', service: anikoto, type: 'direct' },
            { name: 'animeunity', service: consumet, type: 'consumet' },
            { name: 'animesaturn', service: consumet, type: 'consumet' },
        ];
        this.availableProviders = allProviders.filter(p => !disabled.includes(p.name));
        if (disabled.length > 0) {
            console.log(`[Orchestrator] Disabled providers: ${disabled.join(', ')}. Active: ${this.availableProviders.map(p => p.name).join(', ')}`);
        }
        this.providerHealth = {}; // { name: { failures: 0, openUntil: null } }
    }

    isProviderHealthy(name) {
        const h = this.providerHealth[name];
        if (!h || h.failures < 3) return true;
        if (h.openUntil && Date.now() < h.openUntil) return false;
        return true; // Cooldown expired
    }

    recordFailure(name) {
        if (!this.providerHealth[name]) this.providerHealth[name] = { failures: 0 };
        this.providerHealth[name].failures++;
        if (this.providerHealth[name].failures >= 3) {
            console.log(`[Orchestrator] Opening circuit for ${name} due to repeated failures`);
            this.providerHealth[name].openUntil = Date.now() + 60000; // 1 min cooldown
        }
    }

    recordSuccess(name) {
        this.providerHealth[name] = { failures: 0, openUntil: null };
    }

    getProviders(preferredProvider) {
        let providers = [...this.availableProviders];
        let providerName = preferredProvider;

        if (providerName) {
            const index = providers.findIndex(p => p.name === providerName);
            if (index > -1) {
                const p = providers[index];
                const others = providers.filter(x => x.name !== providerName);
                return [p, ...others];
            }
        }
        return providers;
    }

    async fetchAndSaveProviderIds(animeData) {
        const { title, malId, anilistId, altTitles = [], preferredProvider = 'anikoto' } = animeData;
        const currentMapping = await animeMappingService.getMappingByMalId(malId);
        let updates = {};

        // Collect all titles to try for better matching
        const searchTitles = [...new Set([
            title,
            currentMapping?.title_english,
            currentMapping?.title_romaji,
            ...altTitles,
            ...(currentMapping?.title_synonyms || [])
        ])].filter(Boolean);
        
        console.log(`[Orchestrator] Attempting to resolve IDs for MAL ${malId} using titles:`, searchTitles);
        
        return new Promise((resolve) => {
            let earlyResolved = false;
            let completedCount = 0;
            const totalProviders = this.availableProviders.length;

            let graceTimer = null;

            const tryResolve = (reason) => {
                if (earlyResolved) return;
                earlyResolved = true;
                if (graceTimer) clearTimeout(graceTimer);
                console.log(`[Orchestrator] ID resolution resolved: ${reason}`);
                resolve(updates);
            };

            const checkEarlyResolve = () => {
                completedCount++;
                
                // Resolve when PREFERRED provider is found
                if (updates[`${preferredProvider}_id`]) {
                    tryResolve(`Preferred provider (${preferredProvider}) found`);
                    return;
                }
                
                // Resolve when ANY provider ID is found (don't block on preferred)
                const hasAnyId = Object.keys(updates).some(k => k.endsWith('_id'));
                if (!earlyResolved && hasAnyId && !graceTimer) {
                    console.log(`[Orchestrator] First provider ID found. Waiting up to 1000ms for preferred provider ID.`);
                    graceTimer = setTimeout(() => {
                        tryResolve(`Provider found (${Object.keys(updates).filter(k => k.endsWith('_id')).join(', ')}) after grace period`);
                    }, 1000);
                    return;
                }
                
                // Resolve when all providers have completed
                if (!earlyResolved && completedCount === totalProviders) {
                    tryResolve('All providers completed');
                }
            };

            this.availableProviders.forEach(async (provider) => {
                let id = null;
                try {
                    if (currentMapping && currentMapping[`${provider.name}_id`] && currentMapping[`${provider.name}_verified`] === true) {
                        updates[`${provider.name}_id`] = currentMapping[`${provider.name}_id`];
                        checkEarlyResolve();
                        return;
                    }

                    if (searchTitles && searchTitles.length > 0) {
                        const mainTitle = searchTitles[0];
                        const additionalTitles = searchTitles.slice(1);
                        
                        if (provider.type === 'consumet') {
                            id = await provider.service.resolveAnimeId(provider.name, mainTitle, additionalTitles, malId);
                        } else {
                            id = await provider.service.resolveAnimeId(mainTitle, additionalTitles, malId, anilistId);
                        }
                    }

                    if (id) {
                        updates[`${provider.name}_id`] = id;
                        // Only persist verified status for non-animepahe providers.
                        // animepahe session IDs are ephemeral and change periodically,
                        // so we must never store them in the DB.
                        if (provider.name !== 'animepahe') {
                            updates[`${provider.name}_verified`] = true; 
                            updates[`${provider.name}_last_check`] = new Date();
                        }
                    }
                } catch (error) {
                    console.warn(`[Orchestrator] Error resolving ID for ${provider.name}: ${error.message}`);
                } finally {
                    checkEarlyResolve();
                    
                    // Background update mechanism for the ones that finish late.
                    // Skip animepahe — its session IDs are ephemeral.
                    if (earlyResolved && id && provider.name !== 'animepahe') {
                        const backgroundUpdate = {
                            [`${provider.name}_id`]: id,
                            [`${provider.name}_verified`]: true,
                            [`${provider.name}_last_check`]: new Date()
                        };
                        animeMappingService.updateMapping(malId, backgroundUpdate).catch(() => {});
                    }
                }
            });
            
            // Absolute safety timeout — never hang forever
            setTimeout(() => tryResolve('Safety timeout (15s)'), 15000);
        }).then((resolvedUpdates) => {
            // Save ALL IDs (including ephemeral ones like animepahe_id) to the memory cache
            // so they are instantly available for subsequent requests in this session.
            if (Object.keys(resolvedUpdates).length > 0) {
                const existing = animeMappingService.memoryCache.get(malId) || { mal_id: malId };
                animeMappingService.memoryCache.set(malId, { ...existing, ...resolvedUpdates });
            }

            // Strip animepahe_id before saving to DB — it's session-based and
            // changes periodically, so persisting it would cause stale ID bugs.
            const dbUpdates = Object.fromEntries(
                Object.entries(resolvedUpdates).filter(([k]) => !k.startsWith('animepahe_'))
            );

            if (Object.keys(dbUpdates).length > 0) {
                console.log(`[Orchestrator] Saving initial batch of IDs for MAL ${malId}:`, Object.keys(dbUpdates));
                try {
                    animeMappingService.updateMapping(malId, dbUpdates);
                    if (!isDBConnected()) {
                        console.log(`[Orchestrator] DB disconnected. Kept IDs in memory.`);
                    }
                } catch (dbError) {
                    console.warn(`[Orchestrator] Failed to save IDs: ${dbError.message}. Proceeding.`);
                }
            }
            return resolvedUpdates; // Return full updates (including animepahe) for current request use
        });
    }

    async getEpisodes(title, malId, mapping, preferredProvider, targetEpNum = null, category = 'sub', altTitles = []) {
        const providersToTry = this.getProviders(preferredProvider);
        const startTime = Date.now();

        // Run ALL providers in parallel for maximum speed
        const providerPromises = providersToTry.map(async (provider) => {
            if (!this.isProviderHealthy(provider.name)) {
                console.log(`[Orchestrator] Skipping ${provider.name} - circuit open`);
                return null;
            }

            let providerId = mapping[`${provider.name}_id`];
            
            if (!providerId) {
                try {
                    // Timeout the ID-resolution step per-provider so a slow CF bypass
                    // on animepahe doesn't hold up the entire getEpisodes call.
                    // animepahe gets 8s (it can be slow but we don't wait long).
                    // Others get 12s.
                    const resolveTimeoutMs = provider.name === 'animepahe' ? 5000 : 12000;
                    if (provider.type === 'consumet') {
                        providerId = await Promise.race([
                            provider.service.resolveAnimeId(provider.name, title, altTitles, malId),
                            new Promise((_, rej) => setTimeout(() => rej(new Error('resolve timeout')), resolveTimeoutMs))
                        ]);
                    } else {
                        providerId = await Promise.race([
                            provider.service.resolveAnimeId(title, altTitles, malId, mapping.anilist_id),
                            new Promise((_, rej) => setTimeout(() => rej(new Error('resolve timeout')), resolveTimeoutMs))
                        ]);
                    }
                    if (providerId) {
                        if (provider.name !== 'animepahe') {
                            // Never persist animepahe_id to DB — it's session-based and changes over time.
                            animeMappingService.updateMapping(malId, { [`${provider.name}_id`]: providerId, [`${provider.name}_verified`]: true }).catch(err => {});
                        } else {
                            // Save animepahe_id to memory cache only!
                            const existing = animeMappingService.memoryCache.get(malId) || { mal_id: malId };
                            animeMappingService.memoryCache.set(malId, { ...existing, animepahe_id: providerId });
                        }
                    }
                } catch (e) {}
            }

            if (!providerId) return null;

            // Cache Strategy: Check "all" first, then "page"
            const cacheKeyAll = `eps_${provider.name}_${providerId}_all`;
            const cacheKeyPage = `eps_${provider.name}_${providerId}_${targetEpNum ? Math.ceil(targetEpNum / 30) : 'all'}`;
            
            let cachedInfo = episodeCache.get(cacheKeyAll);
            if (!cachedInfo) cachedInfo = episodeCache.get(cacheKeyPage);

            if (cachedInfo) {
                this.recordSuccess(provider.name);
                return { provider: provider.name, episodes: cachedInfo.episodes, animeId: cachedInfo.id };
            }

            const timeoutMs = (provider.name === 'animepahe' || provider.name === 'animeunity') ? 30000 : 10000;
            try {
                let info = await Promise.race([
                    provider.type === 'consumet' 
                        ? provider.service.getAnimeById(provider.name, providerId, targetEpNum)
                        : provider.service.getAnimeById(providerId, targetEpNum),
                    new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), timeoutMs))
                ]);

                if (info && info.episodes && info.episodes.length > 0) {
                    if (info.episodes.length > 50 || !targetEpNum) {
                        episodeCache.set(cacheKeyAll, info);
                    } else {
                        episodeCache.set(cacheKeyPage, info);
                    }
                    
                    console.log(`[Orchestrator] ${provider.name} found ${info.episodes.length} episodes.`);
                    this.recordSuccess(provider.name);
                    return { provider: provider.name, episodes: info.episodes, animeId: info.id };
                } else {
                    console.log(`[Orchestrator] ${provider.name} returned no episodes.`);
                }
            } catch (error) {
                // --- Stale session ID recovery (animepahe only) ---
                // animepahe session IDs are ephemeral. A 404 means the stored ID expired.
                // Don't treat this as a provider health failure — just clear the stale ID
                // from memory, re-resolve a fresh one, and retry once within the same request.
                const isStaleId = provider.name === 'animepahe' && error.message !== 'timeout' && (
                    error.statusCode === 404 ||
                    error.message?.toLowerCase().includes('not found') ||
                    error.message?.toLowerCase().includes('resource not found')
                );

                if (isStaleId) {
                    console.log(`[Orchestrator] animepahe: stale session ID detected (${providerId}). Re-resolving...`);
                    // Evict stale ID from memory cache
                    const existingCache = animeMappingService.memoryCache.get(malId) || {};
                    delete existingCache.animepahe_id;
                    animeMappingService.memoryCache.set(malId, existingCache);
                    // Evict stale episode cache entries for the old ID
                    episodeCache.del(cacheKeyAll);
                    episodeCache.del(cacheKeyPage);

                    try {
                        const remainingMs = timeoutMs - (Date.now() - startTime);
                        if (remainingMs > 5000) {
                            // Re-resolve a fresh session ID
                            const freshId = await Promise.race([
                                provider.service.resolveAnimeId(title, altTitles, malId, mapping.anilist_id),
                                new Promise((_, rej) => setTimeout(() => rej(new Error('resolve timeout')), remainingMs - 2000))
                            ]);
                            if (freshId) {
                                console.log(`[Orchestrator] animepahe: resolved fresh ID ${freshId}. Retrying...`);
                                // Save fresh ID to memory cache
                                const cached = animeMappingService.memoryCache.get(malId) || { mal_id: malId };
                                animeMappingService.memoryCache.set(malId, { ...cached, animepahe_id: freshId });

                                const retryInfo = await provider.service.getAnimeById(freshId, targetEpNum);
                                if (retryInfo && retryInfo.episodes && retryInfo.episodes.length > 0) {
                                    const retryCacheKeyAll = `eps_${provider.name}_${freshId}_all`;
                                    const retryCacheKeyPage = `eps_${provider.name}_${freshId}_${targetEpNum ? Math.ceil(targetEpNum / 30) : 'all'}`;
                                    if (retryInfo.episodes.length > 50 || !targetEpNum) {
                                        episodeCache.set(retryCacheKeyAll, retryInfo);
                                    } else {
                                        episodeCache.set(retryCacheKeyPage, retryInfo);
                                    }
                                    console.log(`[Orchestrator] animepahe: retry succeeded with ${retryInfo.episodes.length} episodes.`);
                                    this.recordSuccess(provider.name);
                                    return { provider: provider.name, episodes: retryInfo.episodes, animeId: retryInfo.id };
                                }
                            }
                        }
                    } catch (retryErr) {
                        console.warn(`[Orchestrator] animepahe: stale-ID retry failed: ${retryErr.message}`);
                    }
                    // Stale ID failures don't count against circuit breaker health
                    return null;
                }

                const errorMsg = error.message === 'timeout' ? `Request timed out (${timeoutMs / 1000}s)` : error.message;
                console.warn(`[Orchestrator] ${provider.name} failed: ${errorMsg}`);
                this.recordFailure(provider.name);
            }
            return null;
        });

        let successfulResults = [];
        let completedCount = 0;
        
        // FAST-RETURN strategy: resolve as soon as the FIRST provider returns,
        // with a short grace period for others to arrive.
        await new Promise((resolve) => {
            let graceTimer = null;
            let resolved = false;
            
            const tryResolve = () => {
                if (resolved) return;
                resolved = true;
                if (graceTimer) clearTimeout(graceTimer);
                resolve();
            };

            providerPromises.forEach(p => {
                p.then(res => {
                    completedCount++;
                    if (res) {
                        successfulResults.push(res);
                        
                        const hasPreferred = successfulResults.some(r => r.provider === preferredProvider);
                        
                        // Preferred provider found — start a grace period so the other
                        // provider (anikoto) can also land in successfulResults.
                        // 500ms is too tight when anikoto is still resolving its ID on
                        // first load — use 3000ms so it doesn't get dropped.
                        if (hasPreferred && !graceTimer) {
                            console.log(`[Orchestrator] Preferred provider (${preferredProvider}) found in ${Date.now() - startTime}ms. Waiting up to 3000ms for remaining providers.`);
                            graceTimer = setTimeout(tryResolve, 3000);
                        }
                        // Non-preferred arrived first — wait for the preferred one,
                        // but ONLY if it's actually healthy. If the circuit is open,
                        // there's no point waiting — resolve immediately with what we have.
                        else if (!hasPreferred && successfulResults.length === 1 && !graceTimer) {
                            const preferredHealthy = this.isProviderHealthy(preferredProvider);
                            if (!preferredHealthy) {
                                console.log(`[Orchestrator] First provider (${res.provider}) found. Preferred (${preferredProvider}) circuit open — resolving immediately.`);
                                tryResolve();
                            } else {
                                console.log(`[Orchestrator] First provider (${res.provider}) found in ${Date.now() - startTime}ms. Waiting up to 1500ms for preferred.`);
                                graceTimer = setTimeout(tryResolve, 1500);
                            }
                        }
                    }
                    
                    // All done
                    if (completedCount === providerPromises.length) {
                        tryResolve();
                    }
                }).catch(() => {
                    completedCount++;
                    if (completedCount === providerPromises.length) {
                        tryResolve();
                    }
                });
            });
            
            // Absolute max wait time (60s) to prevent hanging
            setTimeout(tryResolve, 15000);
        });

        console.log(`[Orchestrator] Parallel fetch completed in ${Date.now() - startTime}ms. Found ${successfulResults.length}/${providersToTry.length} providers successfully.`);
        
        if (successfulResults.length < providersToTry.length) {
            const failed = providersToTry.filter(p => !successfulResults.find(r => r.provider === p.name)).map(p => p.name);
            console.log(`[Orchestrator] Missing providers: ${failed.join(', ')}`);
        }

        const isFullyResolved = completedCount === providersToTry.length;
        // anikoto (Koto CDN) is fast and CF-free — prefer it over animepahe which
        // requires a slow Cloudflare bypass on every new session.
        // animepahe remains a valuable fallback when anikoto doesn't have the episode.
        const preferredOrder = ['anikoto', 'animepahe', 'animeunity', 'animesaturn'];
        
        const sortedResults = successfulResults.sort((a, b) => {
            let finalOrder = [...preferredOrder];
            if (category === 'dub') {
                finalOrder = ['animepahe', 'animeunity', 'animesaturn'];
            }
            if (preferredProvider && finalOrder.includes(preferredProvider)) {
                finalOrder = [preferredProvider, ...finalOrder.filter(p => p !== preferredProvider)];
            }
            const idxA = finalOrder.indexOf(a.provider);
            const idxB = finalOrder.indexOf(b.provider);
            return (idxA === -1 ? 99 : idxA) - (idxB === -1 ? 99 : idxB);
        });

        return {
            results: sortedResults,
            isFullyResolved
        };
    }

    async getServers(providerName, episodeId, title = null) {
        if (providerName === 'megaplay') return await megaplay.getServers(episodeId);
        if (providerName === 'anikoto') return await anikoto.getEpisodeServers(episodeId);
        
        const provider = this.availableProviders.find(p => p.name === providerName);
        if (!provider) throw new Error(`Invalid provider: ${providerName}`);

        if (provider.type === 'consumet') {
            return await provider.service.getEpisodeServers(provider.name, episodeId);
        } else {
            return await provider.service.getEpisodeServers(episodeId, title);
        }
    }

    async getSources(title, providerName, episodeId, serverId, category = 'sub', animeId = null, targetEpNum = null) {
        if (providerName === 'megaplay') return await megaplay.getSources(episodeId, serverId, category, animeId, targetEpNum);
        if (providerName === 'anikoto') {
            const result = await anikoto.getEpisodeSources(episodeId, serverId, category);
            // If ALL sources are embed-only (e.g. Kiwi-Stream), normalize to the
            // {isEmbed, embedUrl} shape that the frontend IframeEmbed component expects.
            const allEmbed = result?.sources?.length > 0 && result.sources.every(s => s.is_embed);
            if (allEmbed) {
                const best = result.sources[0];
                return {
                    isEmbed: true,
                    embedUrl: best.url,
                    serverName: best.serverName,
                    cat: best.cat,
                    sources: result.sources, // keep for reference
                    subtitles: result.subtitles || [],
                    intro: result.intro,
                    outro: result.outro,
                };
            }
            return result;
        }
        
        const provider = this.availableProviders.find(p => p.name === providerName);
        if (!provider) throw new Error(`Invalid provider: ${providerName}`);

        let targetServerId = serverId;

        if (provider.type === 'consumet') {
            return await provider.service.getEpisodeSources(provider.name, episodeId, targetServerId);
        } else if (provider.name === 'animepahe') {
            return await provider.service.getEpisodeSources(episodeId, targetServerId, category, animeId);
        } else {
            return await provider.service.getEpisodeSources(episodeId, targetServerId, category);
        }
    }
}

module.exports = new AnimeOrchestrator();

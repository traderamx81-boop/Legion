const axios = require('axios');
const NodeCache = require('node-cache');

const cache = new NodeCache({ stdTTL: 21600 }); // 6-hour cache

const BASE = 'https://raw.githubusercontent.com/RockinChaos/AniSchedule/master/raw';

const URLS = {
    'sub-schedule':     `${BASE}/sub-schedule.json`,
    'dub-schedule':     `${BASE}/dub-schedule.json`,
    'sub-episode-feed': `${BASE}/sub-episode-feed.json`,
    'dub-episode-feed': `${BASE}/dub-episode-feed.json`,
};

const aniScheduleUtils = {
    async fetch(type) {
        const cached = cache.get(type);
        if (cached) return cached;

        const url = URLS[type];
        if (!url) throw new Error(`Unknown AniSchedule type: ${type}`);

        try {
            const response = await axios.get(url, { timeout: 15000 });
            cache.set(type, response.data);
            return response.data;
        } catch (error) {
            console.error(`AniScheduleUtils: Failed to fetch ${type}:`, error.message);
            return null;
        }
    },

    /**
     * Returns recently released sub episodes sorted by most recently aired first.
     *
     * Strategy:
     *  1. sub-episode-feed  → find episodes released within the lookback window (has timestamps, no metadata)
     *  2. sub-schedule      → provides title/image/genre metadata keyed by idMal
     *  3. dub-episode-feed  → sets hasDub flag (any idMal with a dub release in the past 30× window)
     */
    async getRecentEpisodes(pageOrOpts = 1, maybeLimit = 24, maybeLookbackDays = 7, maybeFilter = 'all') {
        let page = 1;
        let limit = 24;
        let lookbackDays = 7;
        let filter = 'all';

        if (typeof pageOrOpts === 'object' && pageOrOpts !== null) {
            page = parseInt(pageOrOpts.page) || 1;
            limit = parseInt(pageOrOpts.limit) || 24;
            lookbackDays = parseInt(pageOrOpts.lookbackDays) || 7;
            filter = pageOrOpts.filter || 'all';
        } else if (typeof pageOrOpts === 'number') {
            if (pageOrOpts > 10 && maybeLimit <= 30) {
                limit = pageOrOpts;
                lookbackDays = maybeLimit || 7;
                page = 1;
            } else {
                page = pageOrOpts || 1;
                limit = maybeLimit || 24;
                lookbackDays = maybeLookbackDays || 7;
                filter = maybeFilter || 'all';
            }
        }

        const [subFeed, subSchedule, dubFeed] = await Promise.all([
            this.fetch('sub-episode-feed'),
            this.fetch('sub-schedule'),
            this.fetch('dub-episode-feed').catch(() => null),
        ]);

        if (!subFeed) return { data: [], pagination: { current_page: page, last_visible_page: 1, has_next_page: false } };

        const now = Date.now();
        const cutoffMs = now - lookbackDays * 24 * 60 * 60 * 1000;

        // Build metadata map from sub-schedule keyed by idMal (and by anilist id)
        const metaByMal = new Map();
        const metaById  = new Map();
        if (subSchedule && Array.isArray(subSchedule)) {
            for (const anime of subSchedule) {
                if (anime.idMal)  metaByMal.set(anime.idMal, anime);
                if (anime.id)     metaById.set(anime.id, anime);
            }
        }

        // Build dub MAL ID set (generous 30× window so slower dub releases aren't missed)
        const dubMalIds = new Set();
        if (dubFeed && Array.isArray(dubFeed)) {
            const dubCutoffMs = now - lookbackDays * 30 * 24 * 60 * 60 * 1000;
            for (const entry of dubFeed) {
                if (!entry.idMal) continue;
                const ts = entry.episode?.airedAt ? new Date(entry.episode.airedAt).getTime() : null;
                if (ts === null || ts >= dubCutoffMs) dubMalIds.add(entry.idMal);
            }
        }

        // Find most-recent episode per show from the sub feed within the lookback window
        // subFeed is ordered newest-first; the first entry per idMal wins
        const seenMal = new Set();
        const allRecent = [];

        for (const entry of subFeed) {
            const malId = entry.idMal;
            if (!malId || seenMal.has(malId)) continue;

            const airedAt = entry.episode?.airedAt;
            if (!airedAt) continue;

            const ts = new Date(airedAt).getTime();
            if (ts < cutoffMs || ts > now) continue; // outside our window

            seenMal.add(malId);

            const hasDub = dubMalIds.has(malId);
            if (filter === 'dub' && !hasDub) continue;
            if (filter === 'sub' && hasDub) continue;

            const meta = metaByMal.get(malId) || metaById.get(entry.id) || null;
            const coverImage = meta?.coverImage?.extraLarge || meta?.coverImage?.medium || '';

            allRecent.push({
                mal_id: malId,
                anilist_id: entry.id,
                title: meta?.title?.english || meta?.title?.romaji || meta?.title?.userPreferred || `Anime #${malId}`,
                title_romaji: meta?.title?.romaji || null,
                coverImage,
                images: {
                    webp: { large_image_url: coverImage },
                    jpg:  { large_image_url: coverImage },
                },
                bannerImage: meta?.bannerImage || null,
                genres: (meta?.genres || []).map(g => ({ name: g })),
                score: 'N/A',
                episodes: null,
                duration: entry.duration || (meta?.duration) || null,
                format: entry.format || (meta?.format) || 'TV',
                year: meta?.seasonYear || null,
                status: 'Currently Airing',
                airing: true,
                isNew: true,
                isNewEpisode: true,
                episodeTitle: `EP ${entry.episode?.aired}`,
                hasDub,
                airingAt: Math.floor(ts / 1000),
            });
        }

        const total = allRecent.length;
        const totalPages = Math.ceil(total / limit) || 1;
        const startIndex = (page - 1) * limit;
        const pagedData = allRecent.slice(startIndex, startIndex + limit);

        return {
            data: pagedData,
            pagination: {
                current_page: page,
                last_visible_page: totalPages,
                has_next_page: page < totalPages,
                items: {
                    count: pagedData.length,
                    total,
                    per_page: limit
                }
            }
        };
    },

    async getScheduleByDay(dayName) {
        const all = await this.fetch('sub-schedule');
        if (!all) return null;

        const dayLower = dayName.toLowerCase();
        const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
        const targetDayIndex = days.indexOf(dayLower);
        if (targetDayIndex === -1) return null;

        const results = all.map(anime => {
            const nodes = anime.airingSchedule?.nodes || [];
            const targetNode = nodes.find(node => {
                return new Date(node.airingAt * 1000).getDay() === targetDayIndex;
            });
            if (!targetNode) return null;

            const timeStr = new Date(targetNode.airingAt * 1000).toLocaleTimeString([], {
                hour: '2-digit', minute: '2-digit', hour12: false
            });

            return {
                mal_id: anime.idMal,
                title: anime.title?.english || anime.title?.romaji || anime.title?.userPreferred,
                images: {
                    jpg: {
                        image_url:       anime.coverImage?.extraLarge || anime.coverImage?.medium,
                        large_image_url: anime.coverImage?.extraLarge,
                        small_image_url: anime.coverImage?.medium,
                    }
                },
                airing: true,
                episodes: null,
                status: 'Currently Airing',
                type: anime.format,
                score: null,
                broadcast: {
                    day: dayName.charAt(0).toUpperCase() + dayName.slice(1),
                    time: timeStr,
                    timezone: 'UTC',
                    string: null
                },
                time: timeStr,
                episode: targetNode.episode || 'TBA',
                airing_info: {
                    episode: targetNode.episode,
                    timestamp: targetNode.airingAt
                }
            };
        });

        return {
            data: results.filter(Boolean),
            pagination: { has_next_page: false, current_page: 1, last_visible_page: 1 }
        };
    }
};

module.exports = aniScheduleUtils;

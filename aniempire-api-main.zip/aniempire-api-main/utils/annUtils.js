const axios = require('axios');
const NodeCache = require('node-cache');
const Bottleneck = require('bottleneck');
const { XMLParser } = require('fast-xml-parser');
const { distance } = require('fastest-levenshtein');
const AnimeMapping = require('../models/AnimeMapping');
const MangaMapping = require('../models/MangaMapping');
const { isDBConnected } = require('../config/db');

// Cache setup
// Encyclopedia entries, cast, and staff are mostly static -> 24 hours
const detailsCache = new NodeCache({ stdTTL: 86400, checkperiod: 3600 });
// News and search can change more frequently -> 1 hour
const newsCache = new NodeCache({ stdTTL: 3600, checkperiod: 600 });
const searchCache = new NodeCache({ stdTTL: 3600, checkperiod: 600 });
const idCache = new NodeCache({ stdTTL: 86400, checkperiod: 3600 });
const latestNewsCache = new NodeCache({ stdTTL: 900, checkperiod: 300 }); // 15 minutes
const articleCache = new NodeCache({ stdTTL: 86400, checkperiod: 3600 }); // 24 hours
const thumbnailCache = new NodeCache({ stdTTL: 86400 * 7, checkperiod: 3600 }); // 7 days

// Anime News Network Encyclopedia strictly requires >= 1s delay between requests
const limiter = new Bottleneck({
    minTime: 1000, // 1 request per second
    maxConcurrent: 1
});

// XML Parser configured for ANN XML
const xmlParser = new XMLParser({
    ignoreAttributes: false,
    attributeNamePrefix: '@_',
    textNodeName: '#text',
    parseAttributeValue: true,
    trimValues: true
});

const ANN_DETAILS_BASE = 'https://cdn.animenewsnetwork.com/encyclopedia/api.xml';

/**
 * Normalizes XML fields that may be either an array or a single object/primitive
 */
const toArray = (val) => {
    if (!val) return [];
    return Array.isArray(val) ? val : [val];
};

/**
 * Extracts string text from an element that may be a primitive or an object with #text
 */
const getText = (val) => {
    if (val === null || val === undefined) return '';
    if (typeof val === 'string' || typeof val === 'number') return String(val).trim();
    if (typeof val === 'object' && val['#text'] !== undefined) return String(val['#text']).trim();
    return '';
};

/**
 * Normalizes a parsed raw anime/manga object from ANN XML
 */
const normalizeAnnItem = (rawItem, fallbackType = 'anime') => {
    if (!rawItem) return null;

    const annId = rawItem['@_id'] ? parseInt(rawItem['@_id']) : null;
    const name = rawItem['@_name'] || '';
    const type = rawItem['@_type'] || fallbackType;
    const precision = rawItem['@_precision'] || '';
    const generatedOn = rawItem['@_generated-on'] || null;

    const infoList = toArray(rawItem.info);
    const titles = {
        main: name,
        english: null,
        japanese: null,
        alternatives: []
    };
    const genres = [];
    const themes = [];
    let picture = null;
    let plotSummary = null;
    let runningTime = null;
    let episodesCount = null;
    let vintage = null;
    let copyright = null;
    let objectionableContent = null;
    const officialWebsites = [];
    const openingThemes = [];
    const endingThemes = [];

    for (const info of infoList) {
        const infoType = info['@_type'];
        const lang = info['@_lang'];
        const text = getText(info);

        switch (infoType) {
            case 'Main title':
                titles.main = text || titles.main;
                break;
            case 'Alternative title':
                if (lang === 'JA' || lang === 'ja') {
                    titles.japanese = text;
                } else if (lang === 'EN' || lang === 'en') {
                    titles.english = text;
                } else {
                    titles.alternatives.push({ title: text, lang });
                }
                break;
            case 'Picture':
                picture = info['@_src'] || info.img?.['@_src'] || picture;
                break;
            case 'Genres':
                if (text && !genres.includes(text)) genres.push(text);
                break;
            case 'Themes':
                if (text && !themes.includes(text)) themes.push(text);
                break;
            case 'Plot Summary':
                plotSummary = text;
                break;
            case 'Running time':
                runningTime = text;
                break;
            case 'Number of episodes':
                episodesCount = parseInt(text) || text;
                break;
            case 'Vintage':
                vintage = text;
                break;
            case 'Copyright notice':
                copyright = text;
                break;
            case 'Objectionable content':
                objectionableContent = text;
                break;
            case 'Official website':
                officialWebsites.push({
                    url: info['@_href'] || text,
                    lang: lang || null
                });
                break;
            case 'Opening Theme':
                if (text) openingThemes.push(text);
                break;
            case 'Ending Theme':
                if (text) endingThemes.push(text);
                break;
            default:
                break;
        }
    }

    // Ratings
    let ratings = null;
    if (rawItem.ratings) {
        ratings = {
            nb_votes: rawItem.ratings['@_nb_votes'] ? parseInt(rawItem.ratings['@_nb_votes']) : 0,
            weighted_score: rawItem.ratings['@_weighted_score'] ? parseFloat(rawItem.ratings['@_weighted_score']) : null,
            bayesian_score: rawItem.ratings['@_bayesian_score'] ? parseFloat(rawItem.ratings['@_bayesian_score']) : null
        };
    }

    // Staff
    const rawStaff = toArray(rawItem.staff);
    const staff = rawStaff.map(s => ({
        task: getText(s.task),
        name: getText(s.person),
        person_id: s.person?.['@_id'] ? parseInt(s.person['@_id']) : null
    })).filter(s => s.name);

    // Cast
    const rawCast = toArray(rawItem.cast);
    const cast = rawCast.map(c => ({
        role: getText(c.role),
        name: getText(c.person),
        person_id: c.person?.['@_id'] ? parseInt(c.person['@_id']) : null,
        lang: c['@_lang'] || null
    })).filter(c => c.name);

    // News
    const rawNews = toArray(rawItem.news);
    const news = rawNews.map(n => ({
        title: getText(n),
        url: n['@_href'] || null,
        datetime: n['@_datetime'] || null
    })).filter(n => n.title && n.url);

    // Reviews
    const rawReviews = toArray(rawItem.review);
    const reviews = rawReviews.map(r => ({
        title: getText(r),
        url: r['@_href'] || null
    })).filter(r => r.url);

    // Related works
    const relatedPrev = toArray(rawItem['related-prev']).map(r => ({
        relation: r['@_rel'] || 'related',
        ann_id: r['@_id'] ? parseInt(r['@_id']) : null
    }));
    const relatedNext = toArray(rawItem['related-next']).map(r => ({
        relation: r['@_rel'] || 'related',
        ann_id: r['@_id'] ? parseInt(r['@_id']) : null
    }));

    return {
        ann_id: annId,
        name,
        type,
        precision,
        generated_on: generatedOn,
        titles,
        picture,
        genres,
        themes,
        plot_summary: plotSummary,
        running_time: runningTime,
        episodes_count: episodesCount,
        vintage,
        copyright,
        objectionable_content: objectionableContent,
        official_websites: officialWebsites,
        opening_themes: openingThemes,
        ending_themes: endingThemes,
        ratings,
        staff,
        cast,
        news,
        reviews,
        related: [...relatedPrev, ...relatedNext]
    };
};

const annUtils = {
    /**
     * Executes an API request with rate limiting and caching
     */
    async withLimitAndCache(cacheInstance, cacheKey, fn) {
        if (cacheInstance) {
            const cached = cacheInstance.get(cacheKey);
            if (cached !== undefined) return cached;
        }

        return await limiter.schedule(async () => {
            if (cacheInstance) {
                const doubleCheck = cacheInstance.get(cacheKey);
                if (doubleCheck !== undefined) return doubleCheck;
            }

            const result = await fn();
            if (cacheInstance && result !== undefined && result !== null) {
                cacheInstance.set(cacheKey, result);
            }
            return result;
        });
    },

    /**
     * Parses raw ANN XML string to JSON
     */
    parseAnnXml(xmlData) {
        try {
            return xmlParser.parse(xmlData);
        } catch (error) {
            console.error('AnnUtils: XML parse error:', error.message);
            return null;
        }
    },

    /**
     * Fetches details directly by ANN ID
     * @param {number|string} annId 
     * @param {'anime'|'manga'} type 
     */
    async fetchDetailsByAnnId(annId, type = 'anime') {
        const id = parseInt(annId);
        if (!id) return null;

        const cacheKey = `ann_details_${type}_${id}`;
        return this.withLimitAndCache(detailsCache, cacheKey, async () => {
            try {
                const response = await axios.get(ANN_DETAILS_BASE, {
                    params: { [type]: id },
                    timeout: 10000,
                    headers: { 'User-Agent': 'aniempire-api/1.0 (compatible; Node.js)' }
                });

                const parsed = this.parseAnnXml(response.data);
                if (!parsed || !parsed.ann) return null;

                const item = parsed.ann.anime || parsed.ann.manga;
                if (!item) return null;

                return normalizeAnnItem(item, type);
            } catch (error) {
                console.error(`AnnUtils: Error fetching ANN ID ${id}:`, error.message);
                if (error.response?.status === 404) return null;
                throw error;
            }
        });
    },

    /**
     * Searches ANN by title (?title=~query)
     * @param {string} query 
     */
    async searchAnn(query) {
        if (!query || typeof query !== 'string') return [];
        const trimmed = query.trim();
        if (!trimmed) return [];

        const cacheKey = `ann_search_${trimmed.toLowerCase()}`;
        return this.withLimitAndCache(searchCache, cacheKey, async () => {
            try {
                const response = await axios.get(ANN_DETAILS_BASE, {
                    params: { title: `~${trimmed}` },
                    timeout: 10000,
                    headers: { 'User-Agent': 'aniempire-api/1.0 (compatible; Node.js)' }
                });

                const parsed = this.parseAnnXml(response.data);
                if (!parsed || !parsed.ann) return [];

                const results = [];
                const animeList = toArray(parsed.ann.anime);
                const mangaList = toArray(parsed.ann.manga);

                for (const item of animeList) {
                    const normalized = normalizeAnnItem(item, 'anime');
                    if (normalized) results.push(normalized);
                }
                for (const item of mangaList) {
                    const normalized = normalizeAnnItem(item, 'manga');
                    if (normalized) results.push(normalized);
                }

                return results;
            } catch (error) {
                console.error(`AnnUtils: Search error for "${trimmed}":`, error.message);
                return [];
            }
        });
    },

    /**
     * Resolves ANN ID from MAL ID using:
     * 1. DB AnimeMapping / MangaMapping
     * 2. Jikan external links
     * 3. ANN fuzzy search fallback
     * 
     * When found, persists ann_id in DB asynchronously.
     */
    async resolveAnnId(malId, title = null, type = 'anime') {
        const id = parseInt(malId);
        if (!id) return null;

        const cacheKey = `ann_id_mapping_${type}_${id}`;
        const cached = idCache.get(cacheKey);
        if (cached !== undefined) return cached;

        const executeResolution = async () => {
            // 1. Check MongoDB
            if (isDBConnected()) {
                try {
                    const Model = type === 'manga' ? MangaMapping : AnimeMapping;
                    const doc = await Model.findOne({ mal_id: id }).select('ann_id title title_english').lean();
                    if (doc?.ann_id) {
                        return doc.ann_id;
                    }
                    if (!title && (doc?.title || doc?.title_english)) {
                        title = doc.title_english || doc.title;
                    }
                } catch (dbErr) {
                    console.warn(`AnnUtils: DB check failed for MAL ${id}:`, dbErr.message);
                }
            }

            // Helper to match from search results
            const matchFromSearchResults = (searchResults, targetTitle) => {
                if (!searchResults || searchResults.length === 0) return null;
                const cleanTarget = targetTitle.toLowerCase().trim();
                let bestMatch = null;
                let lowestDist = Infinity;

                for (const item of searchResults) {
                    const itemType = (item.type || '').toLowerCase();
                    const isMangaItem = itemType === 'manga' || itemType === 'anthology' || itemType === 'novel';
                    if (type === 'manga' && !isMangaItem) continue;
                    if (type === 'anime' && isMangaItem) continue;

                    const candidate = (item.name || '').toLowerCase().trim();
                    const dist = distance(cleanTarget, candidate);
                    if (dist < lowestDist) {
                        lowestDist = dist;
                        bestMatch = item;
                    }
                }

                const maxAllowedDist = Math.max(3, Math.floor(cleanTarget.length * 0.35));
                if (bestMatch && lowestDist <= maxAllowedDist) {
                    return bestMatch.ann_id;
                }
                return null;
            };

            // 2. If title is provided, try title search first (much faster than cold Jikan external links)
            if (title) {
                try {
                    const searchResults = await this.searchAnn(title);
                    const matchedId = matchFromSearchResults(searchResults, title);
                    if (matchedId) {
                        this._saveAnnIdAsync(id, matchedId, type);
                        return matchedId;
                    }
                } catch (searchErr) {
                    console.warn(`AnnUtils: Title search fallback failed for "${title}":`, searchErr.message);
                }
            }

            // 3. Try Jikan external links
            try {
                const { jikanFunctions } = require('./jikanUtils');
                let externalLinks = [];
                if (type === 'manga') {
                    const externalResp = await jikanFunctions.rawFetch(`https://api.jikan.moe/v4/manga/${id}/external`);
                    externalLinks = externalResp?.data || [];
                } else {
                    const externalResp = await jikanFunctions.loadAnime(id, 'external');
                    externalLinks = externalResp?.data || [];
                }

                for (const link of externalLinks) {
                    const name = (link.name || '').toLowerCase();
                    const url = link.url || '';
                    if (name.includes('anime news network') || name.includes('ann') || url.includes('animenewsnetwork.com')) {
                        const match = url.match(/[?&]id=(\d+)/);
                        if (match) {
                            const annId = parseInt(match[1]);
                            this._saveAnnIdAsync(id, annId, type);
                            return annId;
                        }
                    }
                }
            } catch (jikanErr) {
                console.warn(`AnnUtils: Jikan external links resolution failed for MAL ${id}:`, jikanErr.message);
            }

            // 4. If title was missing, try fetching title from Jikan metadata and searching
            if (!title) {
                try {
                    const { jikanFunctions } = require('./jikanUtils');
                    const endpoint = type === 'manga' ? `https://api.jikan.moe/v4/manga/${id}` : `https://api.jikan.moe/v4/anime/${id}`;
                    const meta = await jikanFunctions.rawFetch(endpoint);
                    const recoveredTitle = meta?.data?.title || meta?.data?.title_english || meta?.data?.title_romaji;
                    if (recoveredTitle) {
                        const searchResults = await this.searchAnn(recoveredTitle);
                        const matchedId = matchFromSearchResults(searchResults, recoveredTitle);
                        if (matchedId) {
                            this._saveAnnIdAsync(id, matchedId, type);
                            return matchedId;
                        }
                    }
                } catch (metaErr) {
                    console.warn(`AnnUtils: Jikan title recovery failed for MAL ${id}:`, metaErr.message);
                }
            }

            return null;
        };

        const result = await executeResolution();
        if (result) {
            idCache.set(cacheKey, result);
        }
        return result;
    },

    /**
     * Persists ann_id to database in the background without blocking the caller
     */
    _saveAnnIdAsync(malId, annId, type = 'anime') {
        if (!isDBConnected() || !annId) return;
        setImmediate(async () => {
            try {
                const Model = type === 'manga' ? MangaMapping : AnimeMapping;
                await Model.updateOne(
                    { mal_id: malId },
                    { $set: { ann_id: annId, updated_at: new Date() } },
                    { upsert: false }
                );
            } catch (err) {
                console.warn(`AnnUtils: Failed to persist ann_id ${annId} for MAL ${malId}:`, err.message);
            }
        });
    },

    /**
     * Fetches normalized ANN details by MAL ID (resolving ann_id first)
     */
    async fetchAnnByMalId(malId, title = null, type = 'anime') {
        const annId = await this.resolveAnnId(malId, title, type);
        if (!annId) return null;
        return await this.fetchDetailsByAnnId(annId, type);
    },

    /**
     * Returns curated ANN news for an anime or manga
     */
    async getAnnNews(idOrMalId, title = null, type = 'anime', isAnnId = false) {
        let annId = idOrMalId;
        if (!isAnnId) {
            annId = await this.resolveAnnId(idOrMalId, title, type);
        }
        if (!annId) return [];

        const cacheKey = `ann_news_${type}_${annId}`;
        const cached = newsCache.get(cacheKey);
        if (cached) return cached;

        const details = await this.fetchDetailsByAnnId(annId, type);
        const news = details?.news || [];
        newsCache.set(cacheKey, news);
        return news;
    },

    /**
     * Returns structured staff & multilingual voice cast
     */
    async getAnnStaffAndCast(idOrMalId, title = null, type = 'anime', isAnnId = false) {
        let annId = idOrMalId;
        if (!isAnnId) {
            annId = await this.resolveAnnId(idOrMalId, title, type);
        }
        if (!annId) return { staff: [], cast: [] };

        const details = await this.fetchDetailsByAnnId(annId, type);
        return {
            ann_id: annId,
            name: details?.name || null,
            staff: details?.staff || [],
            cast: details?.cast || []
        };
    },

    /**
     * Returns editorial reviews
     */
    async getAnnReviews(idOrMalId, title = null, type = 'anime', isAnnId = false) {
        let annId = idOrMalId;
        if (!isAnnId) {
            annId = await this.resolveAnnId(idOrMalId, title, type);
        }
        if (!annId) return [];

        const details = await this.fetchDetailsByAnnId(annId, type);
        return details?.reviews || [];
    },

    /**
     * Resolves poster thumbnail URL from article page og:image
     */
    async getThumbnailForArticle(articleUrl) {
        if (!articleUrl || typeof articleUrl !== 'string') return null;
        const cached = thumbnailCache.get(articleUrl);
        if (cached !== undefined) return cached;

        try {
            const response = await axios.get(articleUrl, {
                timeout: 10000,
                headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
            });
            const html = response.data;
            const match = html.match(/<meta\s+property=["']og:image["']\s+content=["']([^"']*)["']/i)
                || html.match(/<meta\s+name=["']twitter:image["']\s+content=["']([^"']*)["']/i);
            const thumb = match ? match[1] : null;
            if (thumb) {
                thumbnailCache.set(articleUrl, thumb);
            } else {
                thumbnailCache.set(articleUrl, null, 60); // brief negative cache
            }
            return thumb;
        } catch (err) {
            thumbnailCache.set(articleUrl, null, 60); // 60s cooldown on failed fetch so it can retry
            return null;
        }
    },


    /**
     * Fetches latest global anime/manga news feed from ANN RSS with poster thumbnails
     */
    async fetchLatestNews(page = 1, limit = 20, category = null) {
        const cacheKey = 'ann_latest_news_feed';
        let allItems = latestNewsCache.get(cacheKey);

        if (!allItems) {
            try {
                const response = await axios.get('https://www.animenewsnetwork.com/all/rss.xml?ann-edition=us', {
                    timeout: 12000,
                    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
                });

                const parsed = xmlParser.parse(response.data);
                const rawItems = toArray(parsed?.rss?.channel?.item);

                allItems = rawItems.map(item => {
                    const rawDesc = getText(item.description);
                    const cleanDesc = rawDesc.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();

                    return {
                        title: getText(item.title),
                        url: getText(item.link),
                        guid: getText(item.guid),
                        description: cleanDesc,
                        published_at: item.pubDate ? new Date(item.pubDate).toISOString() : null,
                        category: getText(item.category) || 'Anime'
                    };
                }).filter(i => i.title && i.url);

                latestNewsCache.set(cacheKey, allItems);

                // Warm up thumbnails for top 15 items in background
                setTimeout(async () => {
                    const topItems = allItems.slice(0, 15);
                    for (const it of topItems) {
                        if (!thumbnailCache.has(it.url)) {
                            await this.getThumbnailForArticle(it.url);
                            await new Promise(r => setTimeout(r, 150));
                        }
                    }
                }, 50);
            } catch (err) {
                console.error('AnnUtils: Failed to fetch latest news RSS:', err.message);
                return { data: [], pagination: { total: 0, current_page: 1, last_visible_page: 1, has_next_page: false } };
            }
        }

        let filtered = allItems;
        if (category) {
            const catLower = String(category).toLowerCase();
            filtered = allItems.filter(i => (i.category || '').toLowerCase().includes(catLower));
        }

        const pageNum = Math.max(1, parseInt(page) || 1);
        const limitNum = Math.max(1, parseInt(limit) || 20);
        const startIndex = (pageNum - 1) * limitNum;
        const pageData = filtered.slice(startIndex, startIndex + limitNum);

        // Fetch thumbnails for items on requested page: check cache first, then fetch
        const thumbPromises = pageData.map(async (item) => {
            if (!item.thumbnail) {
                const cached = thumbnailCache.get(item.url);
                if (cached !== undefined) {
                    item.thumbnail = cached;
                } else {
                    item.thumbnail = await this.getThumbnailForArticle(item.url);
                }
            }
        });

        // Cap initial wait to 2500ms so the initial response is fast and doesn't timeout
        await Promise.race([
            Promise.allSettled(thumbPromises),
            new Promise(resolve => setTimeout(resolve, 2500))
        ]);

        // Background resolve remaining pageData items and prefetch next items
        setTimeout(async () => {
            for (const it of pageData) {
                if (!thumbnailCache.has(it.url)) {
                    await this.getThumbnailForArticle(it.url);
                }
            }
            const prefetchSlice = filtered.slice(startIndex + limitNum, startIndex + limitNum + 15);
            for (const it of prefetchSlice) {
                if (!thumbnailCache.has(it.url)) {
                    await this.getThumbnailForArticle(it.url);
                    await new Promise(r => setTimeout(r, 100));
                }
            }
        }, 20);

        return {
            data: pageData.map(item => ({
                title: item.title,
                url: item.url,
                guid: item.guid,
                description: item.description,
                summary: item.description,
                published_at: item.published_at,
                datetime: item.published_at,
                date: item.published_at,
                category: item.category,
                thumbnail: item.thumbnail || thumbnailCache.get(item.url) || null
            })),
            pagination: {
                total: filtered.length,
                current_page: pageNum,
                last_visible_page: Math.max(1, Math.ceil(filtered.length / limitNum)),
                has_next_page: startIndex + limitNum < filtered.length
            }
        };
    },

    /**
     * Fetches full article content for an ANN news URL
     */
    async fetchNewsArticle(articleUrl) {
        if (!articleUrl || typeof articleUrl !== 'string') return null;

        const isAnnUrl = articleUrl.includes('animenewsnetwork.com');
        if (!isAnnUrl) {
            throw new Error('Invalid article URL: Must be from animenewsnetwork.com');
        }

        const cacheKey = `ann_article_${articleUrl}`;
        const cached = articleCache.get(cacheKey);
        if (cached) return cached;

        try {
            const response = await axios.get(articleUrl, {
                timeout: 12000,
                headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
            });

            const html = response.data;

            const titleMatch = html.match(/<h1[^>]*id="page_title"[^>]*>([\s\S]*?)<\/h1>/i)
                || html.match(/<meta\s+property="og:title"\s+content="([^"]*)"/i);
            const title = titleMatch ? titleMatch[1].replace(/<[^>]+>/g, '').trim() : '';

            const descMatch = html.match(/<meta\s+property="og:description"\s+content="([^"]*)"/i);
            const description = descMatch ? descMatch[1].trim() : '';

            const imgMatch = html.match(/<meta\s+property="og:image"\s+content="([^"]*)"/i);
            const thumbnail = imgMatch ? imgMatch[1] : null;

            const timeMatch = html.match(/<time[^>]*datetime="([^"]*)"/i);
            const publishedAt = timeMatch ? timeMatch[1] : null;

            const authorMatch = html.match(/<span\s+class="byline"[^>]*>[\s\S]*?<a[^>]*>([\s\S]*?)<\/a>/i)
                || html.match(/<meta\s+name="author"\s+content="([^"]*)"/i);
            const author = authorMatch ? authorMatch[1].replace(/<[^>]+>/g, '').trim() : null;

            let paragraphs = [];
            let contentHtml = '';

            const meatMatch = html.match(/<div class="meat">([\s\S]*?)<\/div>\s*<div class="meat-feedback">/i)
                || html.match(/<div class="meat">([\s\S]*?)<\/div>/i)
                || html.match(/<div id="content"[^>]*>([\s\S]*?)<\/div>/i);

            if (meatMatch) {
                let rawBody = meatMatch[1];
                rawBody = rawBody.replace(/<script[\s\S]*?<\/script>/gi, '');
                rawBody = rawBody.replace(/<style[\s\S]*?<\/style>/gi, '');

                const pMatches = [...rawBody.matchAll(/<p[^>]*>([\s\S]*?)<\/p>/gi)];
                paragraphs = pMatches.map(m => m[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()).filter(Boolean);
                contentHtml = rawBody.trim();
            }

            // Fallback: if paragraphs is empty, grab all article <p> tags with meaningful text
            if (paragraphs.length === 0) {
                const globalP = [...html.matchAll(/<p[^>]*>([\s\S]*?)<\/p>/gi)];
                paragraphs = globalP.map(m => m[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()).filter(p => p.length > 25);
            }

            const article = {
                title,
                url: articleUrl,
                author,
                published_at: publishedAt,
                thumbnail,
                description,
                paragraphs,
                content_html: contentHtml
            };

            articleCache.set(cacheKey, article);
            return article;
        } catch (err) {
            console.error(`AnnUtils: Failed to fetch article at ${articleUrl}:`, err.message);
            throw err;
        }
    }
};

module.exports = annUtils;

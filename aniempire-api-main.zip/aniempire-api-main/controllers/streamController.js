const axios = require('axios');

// CDN hosts that require Cloudflare bypass (impit). Downloads for these
// are routed through Katalyst's /api/stream/segment proxy instead of
// direct axios, which cannot bypass CF.
const CF_CDN_HOSTS = ['uwucdn.top', 'owocdn.top', 'mewcdn.online', 'bigdreamsmalldih.site'];

function requiresCfBypass(url) {
    try {
        const host = new URL(url).hostname;
        return CF_CDN_HOSTS.some(h => host === h || host.endsWith('.' + h));
    } catch (_) { return false; }
}

exports.downloadMedia = async (req, res) => {
    try {
        let url, referrer, filename;

        let isInlineRequested = false;

        // Support Base64 encoded payload via 'q' query parameter
        if (req.query.q) {
            try {
                const payload = JSON.parse(Buffer.from(req.query.q, 'base64').toString('utf-8'));
                url = payload.url;
                referrer = payload.referrer;
                filename = payload.filename;
                if (payload.inline === true || payload.disposition === 'inline') {
                    isInlineRequested = true;
                }
            } catch (e) {
                return res.status(400).json({ error: 'Invalid encoded payload' });
            }
        } else {
            // Support legacy direct params
            url = req.query.url || req.body.url;
            referrer = req.query.referrer || req.body.referrer;
            filename = req.query.filename || req.body.filename || 'video.mp4';
            if (req.query.inline === 'true' || req.body?.inline === true) {
                isInlineRequested = true;
            }
        }

        if (!url) {
            return res.status(400).json({ error: 'URL is required' });
        }

        const getDisposition = (cType, fname, targetUrl) => {
            if (isInlineRequested) return 'inline';
            const isImg = (cType && cType.startsWith('image/')) ||
                          (fname && /\.(jpe?g|png|webp|gif|svg|avif)$/i.test(fname)) ||
                          /\.(jpe?g|png|webp|gif|svg|avif)($|\?)/i.test(targetUrl);
            return isImg ? 'inline' : 'attachment';
        };

        console.log(`[StreamController] Downloading: ${url}`);
        console.log(`[StreamController] Filename: ${filename}`);
        if (referrer) console.log(`[StreamController] Referrer: ${referrer}`);

        // ── CF-protected CDN: route through Katalyst segment proxy ────────────
        // Direct axios cannot bypass Cloudflare. For known CF CDN hosts we
        // delegate to Katalyst's /api/stream/segment which uses impit +
        // cached cf_clearance cookies.
        if (requiresCfBypass(url)) {
            const streamProxyUrl = process.env.STREAM_PROXY_URL;
            if (!streamProxyUrl) {
                console.error('[StreamController] STREAM_PROXY_URL not set — cannot proxy CF CDN download');
                return res.status(500).json({ error: 'Streaming proxy misconfigured' });
            }
            const katalystOrigin = new URL(streamProxyUrl).origin;
            let segmentProxyUrl = `${katalystOrigin}/api/stream/segment?url=${encodeURIComponent(url)}&download=true&filename=${encodeURIComponent(filename)}`;
            if (referrer && referrer !== 'undefined' && referrer !== 'null') {
                segmentProxyUrl += `&referrer=${encodeURIComponent(referrer)}`;
            }
            console.log(`[StreamController] Routing CF CDN download through Katalyst: ${segmentProxyUrl}`);
            const cfResp = await axios({ method: 'GET', url: segmentProxyUrl, responseType: 'stream', timeout: 120000, maxRedirects: 5, validateStatus: s => s >= 200 && s < 400 });
            const cfContentType = cfResp.headers['content-type'] || 'application/octet-stream';
            const cfContentLength = cfResp.headers['content-length'];
            const disposition = getDisposition(cfContentType, filename, url);
            res.setHeader('Content-Type', cfContentType);
            res.setHeader('Content-Disposition', `${disposition}; filename="${filename.replace(/"/g, '\\"')}"`);
            res.setHeader('Cache-Control', 'public, max-age=86400, s-maxage=86400');
            if (cfContentLength) res.setHeader('Content-Length', cfContentLength);
            cfResp.data.pipe(res);
            cfResp.data.on('error', err => {
                console.error('[StreamController] CF CDN stream error:', err.message);
                if (!res.headersSent) res.status(502).json({ error: 'Error reading from CF CDN stream' });
                else res.end();
            });
            req.on('close', () => cfResp.data.destroy());
            return;
        }
        // ─────────────────────────────────────────────────────────────────────

        // Set up headers for the external request
        const headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        };
        
        if (referrer && referrer !== 'undefined' && referrer !== 'null') {
            headers['Referer'] = referrer;
            headers['Origin'] = new URL(referrer).origin;
        }

        // Fetch the file as a stream
        const response = await axios({
            method: 'GET',
            url: url,
            headers: headers,
            responseType: 'stream',
            timeout: 60000, // 60 seconds connection timeout
            maxRedirects: 5,
            validateStatus: status => status >= 200 && status < 400
        });

        // Forward important headers to the client
        const contentType = response.headers['content-type'] || 'application/octet-stream';
        const contentLength = response.headers['content-length'];
        const disposition = getDisposition(contentType, filename, url);
        
        res.setHeader('Content-Type', contentType);
        res.setHeader('Content-Disposition', `${disposition}; filename="${filename.replace(/"/g, '\\"')}"`);
        res.setHeader('Cache-Control', 'public, max-age=86400, s-maxage=86400'); // Cache for 1 day
        
        if (contentLength) {
            res.setHeader('Content-Length', contentLength);
        }

        // Pipe the external stream to the client response
        response.data.pipe(res);

        // Handle errors during streaming
        response.data.on('error', (err) => {
            console.error('[StreamController] Error during streaming from source:', err.message);
            if (!res.headersSent) {
                res.status(502).json({ error: 'Error reading from source stream' });
            } else {
                res.end(); // End the response if headers already sent
            }
        });

        req.on('close', () => {
            // If the client aborts the request, destroy the source stream to prevent memory leaks
            response.data.destroy();
        });

    } catch (error) {
        console.error('[StreamController] Download error:', error.message);
        
        if (!res.headersSent) {
            res.status(error.response?.status || 500).json({ 
                error: 'Failed to download media',
                message: error.message
            });
        }
    }
};

/**
 * Dedicated proxy for AES-128 decryption keys.
 * Uses arraybuffer (NOT stream) because:
 *   - Keys are exactly 16 bytes — piping a tiny already-buffered response
 *     causes race conditions where the stream ends before pipe() is called,
 *     leaving Express hanging until the 30s proxy timeout fires.
 *   - arraybuffer + res.send() is always reliable for small binary data.
 */
exports.proxyKey = async (req, res) => {
    try {
        const streamProxyUrl = process.env.STREAM_PROXY_URL;
        if (!streamProxyUrl) {
            return res.status(500).json({ error: 'Streaming proxy misconfigured (missing STREAM_PROXY_URL)' });
        }

        const katalystOrigin = new URL(streamProxyUrl).origin;
        const targetUrl = `${katalystOrigin}${req.originalUrl}`;

        console.log(`[StreamController] Proxying KEY request to: ${targetUrl}`);

        const MAX_RETRIES = 2;
        let lastErr = null;
        for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
            if (attempt > 0) {
                const delay = attempt * 500; // 500ms, then 1000ms
                console.log(`[StreamController] Key retry ${attempt}/${MAX_RETRIES - 1} after ${delay}ms...`);
                await new Promise(r => setTimeout(r, delay));
            }
            try {
                const response = await axios({
                    method: 'GET',
                    url: targetUrl,
                    responseType: 'arraybuffer',   // buffer the full key, don't stream
                    timeout: 20000,
                    maxRedirects: 5,
                    validateStatus: s => true,
                });

                // CORS headers — HLS.js fetches keys cross-origin
                res.setHeader('Access-Control-Allow-Origin', '*');
                res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');

                if (response.status === 200) {
                    res.setHeader('Content-Type', 'application/octet-stream');
                    res.setHeader('Content-Length', response.data.byteLength.toString());
                    res.setHeader('Cache-Control', 'no-cache');
                    console.log(`[StreamController] Key OK (${response.data.byteLength} bytes)`);
                    return res.status(200).send(Buffer.from(response.data));
                }

                // Non-200 from Katalyst — forward it directly (no retry needed)
                res.status(response.status);
                res.setHeader('Content-Type', response.headers['content-type'] || 'application/json');
                return res.send(Buffer.from(response.data));

            } catch (err) {
                lastErr = err;
                console.error(`[StreamController] Key proxy error (attempt ${attempt + 1}): ${err.message}`);
                // Only retry on network/timeout errors
                const isRetryable = err.code === 'ECONNABORTED' || err.message?.includes('timeout') || err.code === 'ECONNRESET';
                if (!isRetryable) break;
            }
        }

        if (!res.headersSent) {
            res.status(500).json({ error: 'Key proxy failed after retries', details: lastErr?.message });
        }
    } catch (err) {
        console.error('[StreamController] Key proxy error:', err.message);
        if (!res.headersSent) {
            res.status(500).json({ error: 'Key proxy failed', details: err.message });
        }
    }
};


exports.proxyKatalyst = async (req, res) => {
    try {
        const streamProxyUrl = process.env.STREAM_PROXY_URL;
        if (!streamProxyUrl) {
            console.error('[StreamController] STREAM_PROXY_URL is not set in environment variables');
            return res.status(500).json({ error: 'Streaming proxy is misconfigured (missing STREAM_PROXY_URL)' });
        }

        let katalystOrigin;
        try {
            const urlObj = new URL(streamProxyUrl);
            katalystOrigin = urlObj.origin;
        } catch (e) {
            console.error('[StreamController] Invalid STREAM_PROXY_URL:', streamProxyUrl);
            return res.status(500).json({ error: 'Invalid STREAM_PROXY_URL in environment' });
        }

        // Reconstruct the destination URL (req.originalUrl preserves path and query parameters)
        const targetUrl = `${katalystOrigin}${req.originalUrl}`;

        console.log(`[StreamController] Proxying ${req.method} request to: ${targetUrl}`);

        // Forward headers from client, but strip host and connection headers
        const headers = { ...req.headers };
        delete headers.host;
        delete headers.connection;

        // Retry loop: up to 2 retries on timeout/network error with exponential back-off.
        // HLS.js does NOT retry failed segment requests on its own, so without this the
        // player stalls and the user must click play manually to continue.
        const MAX_RETRIES = 3; // 1 initial attempt + 2 retries
        let lastErr = null;

        for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
            if (attempt > 0) {
                const delay = attempt * 500; // 500ms, then 1000ms
                console.log(`[StreamController] Segment retry ${attempt}/${MAX_RETRIES - 1} after ${delay}ms for: ${targetUrl.substring(0, 120)}`);
                await new Promise(r => setTimeout(r, delay));
            }

            // If response headers already sent (shouldn't happen mid-retry but guard anyway)
            if (res.headersSent) return;

            try {
                const response = await axios({
                    method: req.method,
                    url: targetUrl,
                    headers: headers,
                    responseType: 'stream',
                    timeout: 30000, // 30s timeout per attempt
                    maxRedirects: 5,
                    validateStatus: status => true // Forward all status codes
                });

                // Set status code
                res.status(response.status);

                // Forward headers from response
                Object.entries(response.headers).forEach(([key, value]) => {
                    res.setHeader(key, value);
                });

                // Pipe response data
                response.data.pipe(res);

                // Clean up stream if client disconnects early
                req.on('close', () => {
                    response.data.destroy();
                });

                return; // Success — stop retry loop

            } catch (err) {
                lastErr = err;
                const isRetryable = err.code === 'ECONNABORTED' || err.message?.includes('timeout') || err.code === 'ECONNRESET' || err.code === 'ETIMEDOUT';
                console.error(`[StreamController] Stream proxy error (attempt ${attempt + 1}/${MAX_RETRIES}): ${err.message}`);

                if (!isRetryable) break; // Non-timeout error — don't retry
            }
        }

        // All attempts exhausted
        if (!res.headersSent) {
            res.status(500).json({ error: 'Proxy streaming request failed after retries', details: lastErr?.message });
        }

    } catch (err) {
        console.error('[StreamController] Stream proxy error:', err.message);
        if (!res.headersSent) {
            res.status(500).json({ error: 'Proxy streaming request failed', details: err.message });
        }
    }
};


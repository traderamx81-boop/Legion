const annUtils = require('../utils/annUtils');

/**
 * Controller for Anime News Network Encyclopedia endpoints
 */
const annController = {
    /**
     * GET /api/anime/:id/ann
     * Fetches full ANN details for an anime by MAL ID (or ANN ID if ?isAnnId=true)
     */
    async getAnimeAnnDetails(req, res, next) {
        const { id } = req.params;
        const { title, isAnnId } = req.query;

        try {
            let details = null;
            if (isAnnId === 'true') {
                details = await annUtils.fetchDetailsByAnnId(id, 'anime');
            } else {
                details = await annUtils.fetchAnnByMalId(id, title, 'anime');
            }

            if (!details) {
                return res.status(404).json({
                    error: 'Not Found',
                    message: `Anime News Network entry not found for ID ${id}`
                });
            }

            res.json({ data: details });
        } catch (error) {
            console.error(`getAnimeAnnDetails error for ID ${id}:`, error.message);
            next(error);
        }
    },

    /**
     * GET /api/anime/:id/ann/news
     * Fetches editorial news articles from ANN for an anime
     */
    async getAnimeAnnNews(req, res, next) {
        const { id } = req.params;
        const { title, isAnnId, page = 1, limit = 20 } = req.query;

        try {
            const isAnn = isAnnId === 'true';
            const allNews = await annUtils.getAnnNews(id, title, 'anime', isAnn);

            const pageNum = Math.max(1, parseInt(page) || 1);
            const limitNum = Math.max(1, parseInt(limit) || 20);
            const startIndex = (pageNum - 1) * limitNum;
            const paginatedNews = allNews.slice(startIndex, startIndex + limitNum);

            res.json({
                data: paginatedNews,
                pagination: {
                    total: allNews.length,
                    current_page: pageNum,
                    last_visible_page: Math.max(1, Math.ceil(allNews.length / limitNum)),
                    has_next_page: startIndex + limitNum < allNews.length
                }
            });
        } catch (error) {
            console.error(`getAnimeAnnNews error for ID ${id}:`, error.message);
            next(error);
        }
    },

    /**
     * GET /api/anime/:id/ann/staff
     * Fetches staff credits and multilingual voice cast
     */
    async getAnimeAnnStaff(req, res, next) {
        const { id } = req.params;
        const { title, isAnnId, lang } = req.query;

        try {
            const isAnn = isAnnId === 'true';
            const result = await annUtils.getAnnStaffAndCast(id, title, 'anime', isAnn);

            let cast = result.cast || [];
            if (lang) {
                const targetLang = String(lang).toUpperCase();
                cast = cast.filter(c => c.lang && c.lang.toUpperCase() === targetLang);
            }

            res.json({
                ann_id: result.ann_id,
                name: result.name,
                staff: result.staff || [],
                cast
            });
        } catch (error) {
            console.error(`getAnimeAnnStaff error for ID ${id}:`, error.message);
            next(error);
        }
    },

    /**
     * GET /api/anime/:id/ann/reviews
     * Fetches editorial reviews from ANN
     */
    async getAnimeAnnReviews(req, res, next) {
        const { id } = req.params;
        const { title, isAnnId } = req.query;

        try {
            const isAnn = isAnnId === 'true';
            const reviews = await annUtils.getAnnReviews(id, title, 'anime', isAnn);
            res.json({ data: reviews });
        } catch (error) {
            console.error(`getAnimeAnnReviews error for ID ${id}:`, error.message);
            next(error);
        }
    },

    /**
     * GET /api/manga/:id/ann
     * Fetches full ANN details for a manga by MAL ID
     */
    async getMangaAnnDetails(req, res, next) {
        const { id } = req.params;
        const { title, isAnnId } = req.query;

        try {
            let details = null;
            if (isAnnId === 'true') {
                details = await annUtils.fetchDetailsByAnnId(id, 'manga');
            } else {
                details = await annUtils.fetchAnnByMalId(id, title, 'manga');
            }

            if (!details) {
                return res.status(404).json({
                    error: 'Not Found',
                    message: `Anime News Network entry not found for ID ${id}`
                });
            }

            res.json({ data: details });
        } catch (error) {
            console.error(`getMangaAnnDetails error for ID ${id}:`, error.message);
            next(error);
        }
    },

    /**
     * GET /api/manga/:id/ann/news
     * Fetches editorial news articles from ANN for a manga
     */
    async getMangaAnnNews(req, res, next) {
        const { id } = req.params;
        const { title, isAnnId, page = 1, limit = 20 } = req.query;

        try {
            const isAnn = isAnnId === 'true';
            const allNews = await annUtils.getAnnNews(id, title, 'manga', isAnn);

            const pageNum = Math.max(1, parseInt(page) || 1);
            const limitNum = Math.max(1, parseInt(limit) || 20);
            const startIndex = (pageNum - 1) * limitNum;
            const paginatedNews = allNews.slice(startIndex, startIndex + limitNum);

            res.json({
                data: paginatedNews,
                pagination: {
                    total: allNews.length,
                    current_page: pageNum,
                    last_visible_page: Math.max(1, Math.ceil(allNews.length / limitNum)),
                    has_next_page: startIndex + limitNum < allNews.length
                }
            });
        } catch (error) {
            console.error(`getMangaAnnNews error for ID ${id}:`, error.message);
            next(error);
        }
    },

    /**
     * GET /api/ann/search?q=...
     * Direct title search on ANN
     */
    async searchAnn(req, res, next) {
        const query = req.query.q || req.query.query;
        if (!query) {
            return res.status(400).json({ error: 'Search query parameter (q) is required' });
        }

        try {
            const results = await annUtils.searchAnn(query);
            res.json({
                query,
                count: results.length,
                data: results
            });
        } catch (error) {
            console.error(`searchAnn error for "${query}":`, error.message);
            next(error);
        }
    },

    /**
     * GET /api/ann/details/:annId
     * Direct lookup by ANN ID
     */
    async getAnnDetailsById(req, res, next) {
        const { annId } = req.params;
        const { type = 'anime' } = req.query;

        try {
            const details = await annUtils.fetchDetailsByAnnId(annId, type);
            if (!details) {
                return res.status(404).json({
                    error: 'Not Found',
                    message: `Anime News Network entry not found for ANN ID ${annId}`
                });
            }
            res.json({ data: details });
        } catch (error) {
            console.error(`getAnnDetailsById error for ${annId}:`, error.message);
            next(error);
        }
    },

    /**
     * GET /api/ann/news/latest
     * Returns latest global anime/manga news feed with title, summary, url, date, category
     */
    async getLatestNews(req, res, next) {
        const { page = 1, limit = 20, category } = req.query;
        try {
            const feed = await annUtils.fetchLatestNews(page, limit, category);
            res.json(feed);
        } catch (error) {
            console.error('getLatestNews error:', error.message);
            next(error);
        }
    },

    /**
     * GET /api/ann/news/article?url=...
     * Fetches full article content (headline, author, date, thumbnail, paragraphs, html)
     */
    async getNewsArticle(req, res, next) {
        const articleUrl = req.query.url;
        if (!articleUrl) {
            return res.status(400).json({ error: 'url parameter is required' });
        }

        try {
            const article = await annUtils.fetchNewsArticle(articleUrl);
            if (!article) {
                return res.status(404).json({ error: 'Article not found' });
            }
            res.json({ data: article });
        } catch (error) {
            console.error('getNewsArticle error:', error.message);
            res.status(502).json({
                error: 'Failed to fetch news article',
                message: error.message
            });
        }
    },

    /**
     * GET /api/ann/news/thumbnail?url=...
     * Resolves poster thumbnail for an article URL
     */
    async getNewsThumbnail(req, res, next) {
        const articleUrl = req.query.url;
        if (!articleUrl) {
            return res.status(400).json({ error: 'url parameter is required' });
        }
        try {
            const thumbnail = await annUtils.getThumbnailForArticle(articleUrl);
            res.json({ thumbnail });
        } catch (error) {
            res.json({ thumbnail: null });
        }
    }
};

module.exports = annController;


const mongoose = require('mongoose');

const challengeSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    minlength: 5,
    maxlength: 200
  },
  description: {
    type: String,
    required: true,
    minlength: 10,
    maxlength: 1000
  },
  type: {
    type: String,
    enum: ['easy', 'medium', 'hard', 'legendary'],
    default: 'medium'
  },
  xpReward: {
    type: Number,
    required: true,
    min: 10,
    max: 10000
  },
  creditsReward: {
    type: Number,
    default: 0
  },
  participants: [
    {
      userId: mongoose.Schema.Types.ObjectId,
      joinedAt: { type: Date, default: Date.now },
      completed: { type: Boolean, default: false },
      completedAt: Date
    }
  ],
  participantCount: { type: Number, default: 0 },
  objective: String,
  requirements: [String],
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  isActive: { type: Boolean, default: true },
  startDate: Date,
  endDate: Date,
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}, { timestamps: true });

// Index for efficient queries
challengeSchema.index({ isActive: 1, endDate: 1 });
challengeSchema.index({ type: 1, createdAt: -1 });
challengeSchema.index({ 'participants.userId': 1 });

module.exports = mongoose.model('Challenge', challengeSchema);

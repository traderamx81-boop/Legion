const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    minlength: 5,
    maxlength: 200
  },
  description: {
    type: String,
    required: true,
    minlength: 10,
    maxlength: 1000
  },
  type: {
    type: String,
    enum: ['seasonal', 'marathon', 'community_vote', 'clan_war', 'special'],
    default: 'special'
  },
  rewards: {
    xp: { type: Number, default: 0 },
    credits: { type: Number, default: 0 },
    badge: String,
    title: String
  },
  participants: [
    {
      userId: mongoose.Schema.Types.ObjectId,
      joinedAt: { type: Date, default: Date.now },
      completed: { type: Boolean, default: false },
      completedAt: Date
    }
  ],
  participantCount: { type: Number, default: 0 },
  maxParticipants: { type: Number, default: null },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  isActive: { type: Boolean, default: true },
  startDate: {
    type: Date,
    required: true
  },
  endDate: {
    type: Date,
    required: true
  },
  banner: String,
  rules: [String],
  leaderboard: [
    {
      userId: mongoose.Schema.Types.ObjectId,
      username: String,
      score: Number,
      rank: Number,
      completedAt: Date
    }
  ],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}, { timestamps: true });

// Index for efficient queries
eventSchema.index({ isActive: 1, endDate: 1 });
eventSchema.index({ type: 1, startDate: -1 });
eventSchema.index({ 'participants.userId': 1 });
eventSchema.index({ startDate: 1, endDate: 1 });

module.exports = mongoose.model('Event', eventSchema);

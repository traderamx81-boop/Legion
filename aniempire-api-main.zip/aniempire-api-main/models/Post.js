const mongoose = require('mongoose');

const replySchema = new mongoose.Schema({
  _id: mongoose.Schema.Types.ObjectId,
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  user: {
    _id: mongoose.Schema.Types.ObjectId,
    username: String,
    avatar: String,
    xp: { type: Number, default: 0 },
    role: { type: String, default: 'user' }
  },
  content: {
    type: String,
    required: true,
    minlength: 1,
    maxlength: 5000
  },
  likes: [mongoose.Schema.Types.ObjectId],
  likeCount: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

const postSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  user: {
    _id: mongoose.Schema.Types.ObjectId,
    username: String,
    avatar: String,
    xp: { type: Number, default: 0 },
    role: { type: String, default: 'user' }
  },
  title: {
    type: String,
    required: true,
    minlength: 3,
    maxlength: 200
  },
  content: {
    type: String,
    required: true,
    minlength: 10,
    maxlength: 10000
  },
  category: {
    type: String,
    enum: ['Discussion', 'News', 'Recommendation', 'Question', 'Artwork', 'Meme'],
    default: 'Discussion'
  },
  media: [
    {
      url: String,
      type: { type: String, enum: ['image', 'video'] }
    }
  ],
  likes: [mongoose.Schema.Types.ObjectId],
  replies: [replySchema],
  isPinned: { type: Boolean, default: false },
  replyCount: { type: Number, default: 0 },
  viewCount: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}, { timestamps: true });

// Index for efficient queries
postSchema.index({ category: 1, createdAt: -1 });
postSchema.index({ userId: 1 });
postSchema.index({ isPinned: 1, createdAt: -1 });

module.exports = mongoose.model('Post', postSchema);

const mongoose = require('mongoose');

const activitySchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  user: {
    _id: mongoose.Schema.Types.ObjectId,
    username: String,
    avatar: String,
    xp: { type: Number, default: 0 }
  },
  type: {
    type: String,
    enum: ['watch', 'review', 'post', 'comment', 'achievement', 'level_up', 'clan_join', 'streak', 'milestone', 'follow'],
    required: true
  },
  data: {
    title: String,
    details: String,
    link: String,
    metadata: mongoose.Schema.Types.Mixed
  },
  relatedItemId: mongoose.Schema.Types.ObjectId,
  relatedItemType: String,
  isPublic: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now }
}, { timestamps: true });

// Index for efficient queries
activitySchema.index({ userId: 1, createdAt: -1 });
activitySchema.index({ type: 1, createdAt: -1 });
activitySchema.index({ createdAt: -1 });
activitySchema.index({ isPublic: 1, createdAt: -1 });

module.exports = mongoose.model('Activity', activitySchema);

const mongoose = require('mongoose');

const xpTransactionSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  action: {
    type: String,
    enum: ['watch-episode', 'read-chapter', 'write-review', 'comment', 'reply', 'like', 'community-post', 'follow', 'rate-episode', 'add-to-list', 'daily-login'],
    required: true
  },
  xpAmount: {
    type: Number,
    required: true,
    min: 0
  },
  credits: {
    type: Number,
    default: 0,
    min: 0
  },
  metadata: {
    malId: Number,
    episodeNumber: Number,
    chapterId: String,
    itemType: String,
    itemId: mongoose.Schema.Types.ObjectId
  },
  granted: { type: Boolean, default: true },
  leveledUp: { type: Boolean, default: false },
  oldLevel: Number,
  newLevel: Number,
  donorMultiplier: { type: Number, default: 1 },
  multipliedXP: Number,
  multipliedCredits: Number,
  createdAt: { type: Date, default: Date.now }
});

// Index for efficient queries
xpTransactionSchema.index({ userId: 1, createdAt: -1 });
xpTransactionSchema.index({ action: 1, createdAt: -1 });
xpTransactionSchema.index({ granted: 1, createdAt: -1 });
xpTransactionSchema.index({ leveledUp: 1 });
xpTransactionSchema.index({ createdAt: -1 });

module.exports = mongoose.model('XpTransaction', xpTransactionSchema);

const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  type: {
    type: String,
    enum: ['like', 'reply', 'follow', 'mention', 'achievement', 'event_update', 'challenge_update'],
    required: true
  },
  relatedUser: {
    _id: mongoose.Schema.Types.ObjectId,
    username: String,
    avatar: String
  },
  relatedItemId: mongoose.Schema.Types.ObjectId,
  relatedItemType: String,
  title: String,
  message: String,
  read: { type: Boolean, default: false },
  readAt: Date,
  link: String,
  createdAt: { type: Date, default: Date.now },
  expiresAt: { type: Date, default: () => new Date(+new Date() + 30*24*60*60*1000) } // 30 days
}, { timestamps: true });

// Index for efficient queries
notificationSchema.index({ userId: 1, read: 1, createdAt: -1 });
notificationSchema.index({ userId: 1, createdAt: -1 });
notificationSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 }); // TTL index

module.exports = mongoose.model('Notification', notificationSchema);

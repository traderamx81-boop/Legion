const mongoose = require('mongoose');

const discussionSchema = new mongoose.Schema({
  authorId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  author: {
    _id: mongoose.Schema.Types.ObjectId,
    username: String,
    avatar: String,
    xp: { type: Number, default: 0 },
    role: { type: String, default: 'user' }
  },
  title: {
    type: String,
    required: true,
    minlength: 3,
    maxlength: 200
  },
  content: {
    type: String,
    required: true,
    minlength: 10,
    maxlength: 10000
  },
  category: {
    type: String,
    enum: ['general', 'anime', 'manga', 'recommendations', 'news', 'fanart', 'memes', 'help'],
    default: 'general'
  },
  likes: [mongoose.Schema.Types.ObjectId],
  likeCount: { type: Number, default: 0 },
  comments: [{
    userId: mongoose.Schema.Types.ObjectId,
    username: String,
    content: String,
    createdAt: { type: Date, default: Date.now }
  }],
  commentCount: { type: Number, default: 0 },
  viewCount: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}, { timestamps: true });

// Index for efficient queries
discussionSchema.index({ category: 1, createdAt: -1 });
discussionSchema.index({ authorId: 1 });
discussionSchema.index({ likeCount: -1 });

module.exports = mongoose.model('Discussion', discussionSchema);

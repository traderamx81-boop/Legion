const express = require('express');
const { 
    searchAnn, 
    getAnnDetailsById, 
    getLatestNews, 
    getNewsArticle,
    getNewsThumbnail 
} = require('../controllers/annController');

const router = express.Router();

router.get('/ann/news/latest', getLatestNews);
router.get('/ann/news/thumbnail', getNewsThumbnail);
router.get('/ann/news/article', getNewsArticle);
router.get('/ann/search', searchAnn);
router.get('/ann/details/:annId', getAnnDetailsById);

module.exports = router;


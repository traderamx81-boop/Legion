const express = require('express');
const router = express.Router();
const streamController = require('../controllers/streamController');

router.get('/download', streamController.downloadMedia);
router.post('/download', streamController.downloadMedia);

// Dedicated key handler: uses arraybuffer (not stream) to avoid pipe timing issues
// with tiny 16-byte AES-128 decryption keys.
router.get('/key', streamController.proxyKey);

// Wildcard route to proxy any other stream requests to the streaming server
router.all('*', streamController.proxyKatalyst);

module.exports = router;
